package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.BaseDto;
import com.cpc.channel.partner.connect.dto.FeedbackAndRatingDto;
import com.cpc.channel.partner.connect.dto.FeedbackDto;

import java.util.List;

public interface FeedBackAndRatingService {

    List<FeedbackDto> getFeedback();

    BaseDto saveRating(FeedbackAndRatingDto ratingDto);
}
