package com.cpc.channel.partner.connect.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class UserLoginResponse extends BaseDto {
	
	private long userId;
	
	@JsonProperty(value="sapcode")
    private String sapCode;
    
    private String username;
    
    private String companyName;
    
    private String mobileNo;
    
    private String designation;
    
    private boolean active;
    
    private String addressLine1;
    
    private String addressLine2;
    
    private String addressLine3;
    
    private String city;
    
    private String 	pinCode;
    
    private String locationCode;
    
    private LocalDateTime createdDate;
    
    private LocalDateTime updatedDate;

}
