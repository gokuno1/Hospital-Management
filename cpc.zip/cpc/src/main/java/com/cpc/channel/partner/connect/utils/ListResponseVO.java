package com.cpc.channel.partner.connect.utils;

import java.util.List;

import com.cpc.channel.partner.connect.dto.BaseDto;

public class ListResponseVO<T> extends BaseDto {

	private List<T> list;

	public List<T> getList() {
		return list;
	}

	public void setList(List<T> list) {
		this.list = (List<T>) list;
	}

		
}