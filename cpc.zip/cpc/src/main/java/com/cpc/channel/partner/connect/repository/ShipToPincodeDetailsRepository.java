package com.cpc.channel.partner.connect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cpc.channel.partner.connect.model.ShipToPincodeDetails;

@Repository
public interface ShipToPincodeDetailsRepository extends JpaRepository<ShipToPincodeDetails, Integer>{

	List<ShipToPincodeDetails> findByShipToCode(String shipToCode);
}
