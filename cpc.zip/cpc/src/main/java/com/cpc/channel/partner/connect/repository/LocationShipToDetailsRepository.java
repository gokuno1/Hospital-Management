package com.cpc.channel.partner.connect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cpc.channel.partner.connect.model.LocationShipToDetails;

@Repository
public interface LocationShipToDetailsRepository extends JpaRepository<LocationShipToDetails, Integer>{

	List<LocationShipToDetails> findByLocationCode(String locationCode);
}
