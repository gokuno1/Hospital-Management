package com.cpc.channel.partner.connect.service;

import java.time.LocalDateTime;
import java.util.List;

import com.cpc.channel.partner.connect.dto.*;
import com.cpc.channel.partner.connect.model.OrderMaster;
import com.cpc.channel.partner.connect.model.OrderSku;

public interface OrderService {


    OrderMaster getOrder(long orderId);

    OrderSku getSkuOrder(long orderId);
    
    BaseDto addNtProductsToCart(CartDto cartDto);
    
    BaseDto updateCart(CartDto cartDto);
    
    CartListDto getCartList(String sapCode, String segmentCode);

    int getCartCount(String sapCode,String segmentCode);
    
    BaseDto removeProductFromCart(String sapCode, String productCode);
    
    BaseDto deleteAllItemsFromCart(String sapCode, String segmentCode);
    
    PlaceOrderResponse placeNtOrder(PlaceOrderRequest placeOrder);
    
    ListResponse<OrderListResponse> getOrderList(String sapCode, String segmentCode, String status, int pageNo);
     
    List<ViewSalesReportDto> getSalesReportDetails(UserRequestDetailsDto salesReportRequest);

    List<ProductWiseSalesDto> getSumOfProductsAsPerMonth(String sapCode, LocalDateTime currentDate);
}
