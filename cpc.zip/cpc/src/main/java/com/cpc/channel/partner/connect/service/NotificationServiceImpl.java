package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.NotificationDetailsDto;
import com.cpc.channel.partner.connect.repository.NotificationDetailsRepository;
import lombok.RequiredArgsConstructor;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationServiceImpl implements NotificationService{

    private final NotificationDetailsRepository notificationDetailsRepository;

    private final DozerBeanMapper mapper;

    private static <T, U> List<U> listMap(Mapper mapper, List<T> source, Class<U> destType) {
        List<U> dest = new ArrayList<>();
        source.stream().forEach(element -> dest.add(mapper.map(element, destType)));
        return dest;
    }


    @Override
    public List<NotificationDetailsDto> getDetailsList(String sapCode) {
        return listMap(mapper,notificationDetailsRepository.findBySapCode(sapCode), NotificationDetailsDto.class);
    }

    @Override
    public int getNotificationCount(String sapCode) {
        return listMap(mapper, notificationDetailsRepository.findBySapCode(sapCode), NotificationDetailsDto.class).size();
    }
}
