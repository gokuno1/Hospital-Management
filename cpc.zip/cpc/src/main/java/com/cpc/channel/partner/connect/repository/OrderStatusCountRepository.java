package com.cpc.channel.partner.connect.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cpc.channel.partner.connect.model.OrderStatusCount;

@Repository
public interface OrderStatusCountRepository extends JpaRepository<OrderStatusCount, String>{

	@Query(value = "select count(ORDER_ID) AS ORDER_COUNT, ORDER_STATUS FROM cpc_service.order_master where ORDER_STATUS IS NOT NULL and SAP_CODE=?1 and SEGMENT_CODE=?2 and ORDER_PLACED_DATE between ?3 and ?4 group by ORDER_STATUS", nativeQuery = true)
	List<OrderStatusCount> findOrderCountByStatus(String sapCode, String segmentCode, LocalDateTime fromDate, LocalDateTime toDate);

}
