package com.cpc.channel.partner.connect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "time_slot_details", catalog = "cpc_service")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TimeSlotDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TIME_SLOT_DETAILS_ID")
	private int timeSlotDetailsId;
	
	@Column(name = "TIME_SLOT")
	private String timeSlot;

}
