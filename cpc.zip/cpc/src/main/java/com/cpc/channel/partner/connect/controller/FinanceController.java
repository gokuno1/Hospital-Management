package com.cpc.channel.partner.connect.controller;
import com.cpc.channel.partner.connect.dto.CashDiscountDto;
import com.cpc.channel.partner.connect.dto.FinanceDto;
import com.cpc.channel.partner.connect.dto.FinancePaymentDto;
import com.cpc.channel.partner.connect.service.FinanceService;
import com.cpc.channel.partner.connect.utils.ListResponseVO;

import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/finance")
@RequiredArgsConstructor
public class FinanceController {

    private final FinanceService financeService;


    @GetMapping("/credit-information")
    public ResponseEntity<FinanceDto> getFinanceStats(@RequestHeader String sapCode){
        FinanceDto stat = financeService.getFinanceStats(sapCode);
        return ResponseEntity.ok(stat);
    }

    @GetMapping("/payment")
    public ResponseEntity<ListResponseVO<FinancePaymentDto>> getFinancePaymentList(@RequestHeader String sapCode){
        List<FinancePaymentDto> list = financeService.getFinancePaymentList(sapCode);
        ListResponseVO<FinancePaymentDto> paymentDetails = new ListResponseVO<>();
        paymentDetails.setList(list);
        paymentDetails.setResponseMessage("Payment Details");
        return ResponseEntity.ok(paymentDetails);
    }

    @GetMapping("/cash-discount")
    public ResponseEntity<CashDiscountDto> getCashDiscount(@RequestHeader String sapCode, 
    													   @RequestHeader String monthDate){
        CashDiscountDto item = financeService.getCashDiscount(sapCode,LocalDateTime.parse(monthDate));
        return ResponseEntity.ok(item);
    }


}
