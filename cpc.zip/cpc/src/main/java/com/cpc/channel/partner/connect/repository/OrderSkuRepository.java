package com.cpc.channel.partner.connect.repository;

import com.cpc.channel.partner.connect.model.OrderSku;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderSkuRepository extends JpaRepository<OrderSku, Long> {
	
	Optional<OrderSku> findBySapCodeAndProductCodeAndPlacedFalse(String sapCode, String productCode);
	
	@Query(value = " FROM OrderSku where sapCode=?1 and segmentCode=?2 and placed=?3 GROUP BY productCode")
	List<OrderSku> findAllCartProductsBySapcode(String sapCode, String segmentCode, boolean isPlaced);
	
	@Modifying
    @Transactional
	@Query(value = "DELETE FROM OrderSku WHERE sapCode=?1 AND productCode=?2 AND placed= false")
	void deleteProductFromCart(String sapCode, String productCode);
	
	@Modifying
    @Transactional
	@Query(value = "DELETE FROM OrderSku WHERE sapCode=?1 AND placed= false")
	void deleteAllProductFromCart(String sapCode);
	
	
}
