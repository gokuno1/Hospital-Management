package com.cpc.channel.partner.connect.mapper;

import com.cpc.channel.partner.connect.dto.FeedbackAndRatingDto;
import com.cpc.channel.partner.connect.dto.FeedbackDto;
import com.cpc.channel.partner.connect.model.FeedbackMaster;
import com.cpc.channel.partner.connect.model.OrderRating;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface FeedbackMapper {

    FeedbackDto modelToDto(FeedbackMaster feedbackMaster);

    OrderRating ratingDtoToModel(FeedbackAndRatingDto ratingDto);


}
