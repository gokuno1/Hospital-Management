package com.cpc.channel.partner.connect.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "finance")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Finance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private long Id;

    @Column(name = "SAP_CODE")
    private String sapCode;

    @Column(name = "CREDIT_LIMIT")
    private double creditLimit;

    @Column(name = "OUTSTANDING_AMOUNT")
    private double outstandingAmount;

    @Column(name = "AVAILABLE_CREDIT")
    private double availableCredit;

    @Column(name = "BALANCE")
    private double balance;
}
