package com.cpc.channel.partner.connect.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "order_master")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ORDER_ID")
    private long orderId;
    
    @Column(name = "SAP_ORDER_ID")
    private String sapOrderId;

    @Column(name = "SAP_CODE")
    private String sapCode;

    @Column(name = "SEGMENT_CODE")
    private String segmentCode;

    @Column(name = "SEGMENT_TYPE")
    private String segmentType;

    @Column(name = "PRODUCT_CODE")
    private String productCode;

    @Column(name = "PRODUCT_DESC")
    private String productDesc;

    @Column(name = "VEHICLE_TYPE")
    private String vehicleType;

    @Column(name = "VEHICLE_NO")
    private String vehicleNo;

    @Column(name = "DRIVER_MOBILE_NO")
    private String driverMobileNo;

    @Column(name = "ORDER_QUANTITY")
    private double quantity;

    @Column(name = "ORDER_PLACED_DATE")
    private LocalDateTime orderPlacedDate;

    @Column(name = "DELIVERY_TIME_SLOT")
    private String deliveryTimeSlot;

    @Column(name = "DELIVERY_DATE")
    private LocalDateTime deliveryDate;

    @Column(name = "SPECIAL_INSTRUCTIONS")
    private String specialInstructions;

    @Column(name = "ACKNOWLEDGED_DATE")
    private LocalDateTime acknowledgedDate;

    @Column(name = "ORDER_STATUS")
    private String orderStatus;

    @Column(name = "SHIP_TO_CODE")
    private String shipToCode;

    @Column(name = "SHIP_TO_NAME")
    private String shipToName;

    @Column(name = "INVOICE_NO")
    private String invoiceNo;

    @Column(name = "INVOICE_DATE")
    private LocalDateTime invoiceDate;

    @Column(name = "ETA")
    private LocalDateTime eta;

    @Column(name = "EPOD_DONE")
    private boolean ePod;

    private boolean feedback;

    @Column(name = "DELIVERY_CONFIRMATION_DATE")
    private LocalDateTime deliveryConfirmationDate;

    @OneToOne()
    @JoinColumn(name="DELIVERY_ADDRESS_DETAILS_ID")
    private DeliveryAddress address;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "orderMaster")  // lazy
    private List<OrderSku> orderSkus;

}
