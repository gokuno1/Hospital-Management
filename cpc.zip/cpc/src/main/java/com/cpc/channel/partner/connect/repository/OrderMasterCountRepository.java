package com.cpc.channel.partner.connect.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cpc.channel.partner.connect.model.OrderMasterCount;

@Repository
public interface OrderMasterCountRepository extends JpaRepository<OrderMasterCount, LocalDateTime> {

	@Query(value = "select SUM(ORDER_QUANTITY) AS ORDER_QUANTITY, ORDER_PLACED_DATE from cpc_service.order_master where ORDER_STATUS='COMPLETED' and SAP_CODE=?1 and SEGMENT_CODE=?2 and ORDER_PLACED_DATE between ?3 and ?4 group by ORDER_PLACED_DATE", nativeQuery = true)
	List<OrderMasterCount> getOrderQuantityByDate(String sapCode, String segmentCode, LocalDateTime fromDate, LocalDateTime toDate);
	
	@Query(value = "SELECT om.ORDER_PLACED_DATE, SUM(os.ORDER_QUANTITY) as ORDER_QUANTITY FROM cpc_service.order_master om INNER JOIN cpc_service.order_sku_details os on om.ORDER_ID = os.ORDER_ID where om.ORDER_STATUS='COMPLETED' and om.SAP_CODE=?1 and om.SEGMENT_CODE='NT1001' and om.ORDER_PLACED_DATE between ?2 and ?3 group by om.ORDER_PLACED_DATE", nativeQuery = true)
	List<OrderMasterCount> getOrderQuantityByDateForNtOrder(String sapCode, LocalDateTime fromDate, LocalDateTime toDate);
}
