package com.cpc.channel.partner.connect.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cpc.channel.partner.connect.model.TimeSlotDetails;

@Repository
public interface TimeSlotDetailsRepository extends JpaRepository<TimeSlotDetails, Integer>{

}
