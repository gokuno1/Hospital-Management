package com.cpc.channel.partner.connect.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class TradeOrderDto {

    private String sapCode;

    private String sapOrderId;

    private String segmentCode;

    private String segmentType;

    private String productCode;

    private String productDesc;

    private String deliveryTimeSlot;

    private String shipToCode;

    private String shipToName;

    private LocalDateTime deliveryDate;

    private LocalDateTime orderPlacedDate;

    private LocalDateTime acknowledgedDate;

    private String orderStatus;

    private double quantity;

    private String specialInstructions;

    private String contactNo;

    private String vehicleType;

    private String vehicleNo;

    private String driverMobileNo;

    private boolean feedback;
    
    private boolean ePod;

    private DeliveryAddressDto address;


}
