package com.cpc.channel.partner.connect.controller;

import com.cpc.channel.partner.connect.dto.BaseDto;
import com.cpc.channel.partner.connect.dto.FeedbackAndRatingDto;
import com.cpc.channel.partner.connect.dto.FeedbackDto;
import com.cpc.channel.partner.connect.service.FeedBackAndRatingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/feedback")
@RequiredArgsConstructor
@Slf4j
public class FeedBackAndRatingController {

    private final FeedBackAndRatingService service;

    @GetMapping
    public ResponseEntity<List<FeedbackDto>> getFeedback() {
        List<FeedbackDto> feedback = service.getFeedback();
        return ResponseEntity.ok(feedback);
    }

    @PostMapping
    public ResponseEntity<BaseDto> captureRating(@Valid @RequestBody FeedbackAndRatingDto ratingDto) {
        log.info(" captured rating {}", ratingDto);
        BaseDto response = service.saveRating(ratingDto);
        return ResponseEntity.ok(response);
    }

}
