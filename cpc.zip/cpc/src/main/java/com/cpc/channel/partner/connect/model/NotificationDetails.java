package com.cpc.channel.partner.connect.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "notification_details")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private long id;

    @Column(name = "SAP_CODE")
    private String sapCode;

    @Column(name = "PRODUCT_NAME")
    private String productName;

    @Column(name = "INVOICE_NUMBER")
    private String invoiceNumber;

    @Column(name = "ORDER_PLACED_DATE")
    private LocalDateTime orderPlacedDate;

    @Column(name = "TIME_SLOT")
    private String timeSlot;

    @Column(name = "ORDER_STATUS")
    private String orderStatus;
}
