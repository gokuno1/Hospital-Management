package com.cpc.channel.partner.connect.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FinanceDto {

    private String sapCode;

    private double creditLimit;

    private double outstandingAmount;

    private double availableCredit;

    private double balance;
    
    private double utilizedPercentage;
    
    private double minimumAmount;
}
