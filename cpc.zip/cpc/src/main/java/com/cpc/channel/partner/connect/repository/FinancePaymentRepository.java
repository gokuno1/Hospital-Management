package com.cpc.channel.partner.connect.repository;

import com.cpc.channel.partner.connect.model.FinancePayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FinancePaymentRepository extends JpaRepository<FinancePayment,Long> {

    List<FinancePayment> findBySapCode(String sapCode);

}
