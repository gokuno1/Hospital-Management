package com.cpc.channel.partner.connect.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TradeSalesDto {

    private String sapCode;

    private double targetQuantity;

    private double onGoingQuantity;

    private double balanceQuantity;

    private double achievedQuantity;

    private LocalDateTime orderPlacedDate;

    private LocalDateTime dispatchedDate;

    private LocalDateTime deliveryDate;

    private String orderStatus;
    
    private double currentMonthTargetDays;
    
    private double askingRate;

}
