package com.cpc.channel.partner.connect.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "delivery_address_details")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeliveryAddress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DELIVERY_ADDRESS_DETAILS_ID")
    private long deliveryAddressId;

    @Column(name = "SAP_CODE")
    private String sapCode;

    @Column(name = "ADDRESS_LINE_1")
    private String addressLine1;

    @Column(name = "ADDRESS_LINE_2")
    private String addressLine2;

    @Column(name = "ADDRESS_LINE_3")
    private String addressLine3;

    @Column(name = "ADDRESS_LINE_4")
    private String addressLine4;

    @Column(name = "PINCODE")
    private String pinCode;

    private String city;

    private String state;

    @Column(name = "CONTACT_NAME")
    private String contactName;

    @Column(name = "CONTACT_NUMBER")
    private String contactNo;

    @Column(name = "IS_FAV")
    private boolean favorite;


}
