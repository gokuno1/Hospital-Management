package com.cpc.channel.partner.connect.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ViewSalesReportDto {
	
	private List<InvoiceDetails> invoiceDetails;
	private LocalDateTime orderDate;
	private int invoiceCount;
	private double totalQuantity;
	private String sapOrderId;

}
