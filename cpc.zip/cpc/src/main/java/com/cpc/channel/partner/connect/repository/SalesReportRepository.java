package com.cpc.channel.partner.connect.repository;

import com.cpc.channel.partner.connect.model.SalesReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface SalesReportRepository extends JpaRepository<SalesReport,Long> {

    @Query(value = "select ORDER_ID,SAP_ORDER_ID,SAP_CODE,ORDER_STATUS,ORDER_PLACED_DATE,ORDER_QUANTITY from cpc_service.order_master where SAP_CODE=?1 and SEGMENT_CODE='T1001' and ORDER_PLACED_DATE between ?2 and ?3 order by ORDER_PLACED_DATE DESC",nativeQuery = true)
    List<SalesReport> findBySapCode(String sapCode, LocalDateTime fromDate, LocalDateTime toDate);
}
