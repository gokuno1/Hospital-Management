package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.SalesReportDto;

import java.time.LocalDateTime;
import java.util.List;

public interface SalesReportService {

    List<SalesReportDto> getSalesReport(String sapCode, LocalDateTime currentDate);
}
