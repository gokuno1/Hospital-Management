package com.cpc.channel.partner.connect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cpc.channel.partner.connect.model.SalesTrends;

@Repository
public interface SalesTrendsDetailsRepository extends JpaRepository<SalesTrends, String>{
	
//	@Query(value = "SELECT CURRENT_MONTH_SALES, CONCAT(MONTHNAME(MONTH_DATE),' ',DATE_FORMAT(MONTH_DATE,'%Y')) as MONTH_NAME \r\n" + 
//			"FROM cpc_service.month_sales WHERE SAP_CODE=?1 order by MONTH_DATE DESC limit ?2", nativeQuery = true)
	@Query(value = "SELECT CURRENT_MONTH_SALES, MONTH_DATE as MONTH_NAME \r\n" + 
			"FROM cpc_service.month_sales WHERE SAP_CODE=?1 order by MONTH_DATE DESC limit ?2", nativeQuery = true)
	List<SalesTrends> getMonthWiseSalesDetails(String sapCode, int noOfMonths);

}
