package com.cpc.channel.partner.connect.repository;

import com.cpc.channel.partner.connect.model.TradeSales;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TradeSalesRepository extends JpaRepository<TradeSales,Long> {

   @Query(value = "SELECT * FROM cpc_service.trade_sales where SAP_CODE=?1 and ORDER_PLACED_DATE between ?2 and ?3", nativeQuery = true)
   List<TradeSales> findBySapCode(String sapCode, LocalDateTime fromDate, LocalDateTime toDate);
   
   @Query(value = "SELECT * FROM cpc_service.trade_sales where SAP_CODE=?1 and ORDER_PLACED_DATE between ?2 and ?3", nativeQuery = true)
   TradeSales findBySapCodeAndOrderPlacedDate(String sapCode, LocalDateTime fromDate, LocalDateTime toDate);

}
