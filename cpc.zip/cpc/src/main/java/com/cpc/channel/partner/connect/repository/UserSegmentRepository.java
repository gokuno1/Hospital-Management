package com.cpc.channel.partner.connect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cpc.channel.partner.connect.model.UserSegment;

@Repository
public interface UserSegmentRepository extends JpaRepository<UserSegment, Integer>{
	
	@Query(value = "SELECT * FROM cpc_service.user_segment_mapping where SAP_CODE=?1 and IS_ACTIVE=1", nativeQuery = true)
	List<UserSegment> getSegmentBySapcode(String sapcode);
}
