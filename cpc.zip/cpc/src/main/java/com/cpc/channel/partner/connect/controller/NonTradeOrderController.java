package com.cpc.channel.partner.connect.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cpc.channel.partner.connect.dto.BaseDto;
import com.cpc.channel.partner.connect.dto.CartDto;
import com.cpc.channel.partner.connect.dto.CartListDto;
import com.cpc.channel.partner.connect.dto.ListResponse;
import com.cpc.channel.partner.connect.dto.OrderListResponse;
import com.cpc.channel.partner.connect.dto.PlaceOrderRequest;
import com.cpc.channel.partner.connect.dto.PlaceOrderResponse;
import com.cpc.channel.partner.connect.service.OrderService;
import com.cpc.channel.partner.connect.utils.ResponseUtils;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/nt-orders")
@RequiredArgsConstructor
public class NonTradeOrderController {

	private final OrderService orderService;

	@PostMapping("/cart")
	@Operation(description = "Add products to cart")
	public ResponseEntity<BaseDto> addToCart(@RequestBody CartDto cartDto){
		BaseDto cartResponse = orderService.addNtProductsToCart(cartDto);
		return ResponseUtils.getOKResponse(cartResponse);
	}

	@GetMapping("/cart")
	@Operation(description = "Get products added to the cart by Sapcode")
	public ResponseEntity<CartListDto> getCart(@RequestHeader String sapCode,
											   @RequestHeader String segmentCode){
		CartListDto cartResponse = orderService.getCartList(sapCode, segmentCode);
		return ResponseUtils.getOKResponse(cartResponse);
	}

	@GetMapping("/cart-count")
	public ResponseEntity<Integer> getCartCount(@RequestHeader String sapCode, @RequestHeader String segmentCode){
		int cartCount = orderService.getCartCount(sapCode, segmentCode);
		return ResponseEntity.ok(cartCount);
	}

	@PutMapping("/cart")
	@Operation(description = "Update product quantity for products in cart")
	public ResponseEntity<BaseDto> updateCartDetails(@RequestBody CartDto cartDto){
		BaseDto cartResponse = orderService.updateCart(cartDto);
		return ResponseUtils.getOKResponse(cartResponse);
	}

	@DeleteMapping("/cart")
	@Operation(description = "Delete product from cart")
	public ResponseEntity<BaseDto> deleteCart(@RequestHeader String sapCode,
											  @RequestHeader String productCode) {
		BaseDto response = orderService.removeProductFromCart(sapCode, productCode);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping("/all-cart")
	@Operation(description = "Delete all products from cart")
	public ResponseEntity<BaseDto> deleteAllItemsFromCart(@RequestHeader String sapCode,
														  @RequestHeader String segmentCode) {
		BaseDto response = orderService.deleteAllItemsFromCart(sapCode, segmentCode);
		return ResponseEntity.ok(response);
	}

	@PostMapping("/order")
	@Operation(description = "Place order for non trade segment (segment 2)")
	public ResponseEntity<PlaceOrderResponse> placeNonTradeOrder(@RequestBody PlaceOrderRequest placeOrder){
		PlaceOrderResponse orderResponse = orderService.placeNtOrder(placeOrder);
		return ResponseUtils.getOKResponse(orderResponse);
	}

	@GetMapping("/orders")
	@Operation(description = "Get Ongoing and Dispatched orders for Non trade (segment 2) segment")
	public ResponseEntity<ListResponse<OrderListResponse>> getOrderList(@RequestHeader String sapCode,
																		@RequestHeader String segmentCode,
																		@RequestHeader String status,
																		@RequestHeader int pageNo){
		ListResponse<OrderListResponse> orderList = orderService.getOrderList(sapCode, segmentCode, status, pageNo);
		return ResponseUtils.getOKResponse(orderList);
	}
}
