package com.cpc.channel.partner.connect.dto;

import lombok.Data;

import java.util.List;

@Data
public class ListResponse <T>{

    private long totalCount;

    private List<T> list;
}
