package com.cpc.channel.partner.connect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "shipto_pincode_details")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShipToPincodeDetails {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SHIPTO_PINCODE_ID")
	private int shipToPincodeId;
	
	@Column(name = "SHIPTO_DESC")
	private String shipToDesc;
	
	@Column(name = "SHIPTO_CODE")
	private String shipToCode;
	
	@Column(name = "PINCODE")
	private String pinCode;
	
	@Column(name = "PINCODE_DESC")
	private String pinCodeDesc;

}
