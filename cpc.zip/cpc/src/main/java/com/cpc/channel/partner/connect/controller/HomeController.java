package com.cpc.channel.partner.connect.controller;

import com.cpc.channel.partner.connect.model.AppUser;
import com.cpc.channel.partner.connect.service.HomeServiceImpl;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
@RequiredArgsConstructor
public class HomeController {

    private final HomeServiceImpl homeService;

    @GetMapping("/hello")
    @Operation(description = "Hello Controller API")
    public String helloWorld() {
        return "Hello World, I am Channel Partner Connect application.";
    }

    @GetMapping("")
    public ResponseEntity<String> greeting() {
        return ResponseEntity.ok("Channel Partner Connect Welcomes You !");
    }

    @GetMapping("/users/{id}")
    public ResponseEntity<AppUser> getUser(@PathVariable long id) {
        AppUser user = homeService.getUser(id);
        return ResponseEntity.ok(user);
    }

}
