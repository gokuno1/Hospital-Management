package com.cpc.channel.partner.connect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "location_shipto_details", catalog = "cpc_service")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LocationShipToDetails {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LOCATION_SHIPTO_ID")
	private int locationShipToId;
	
	@Column(name = "LOCATION_CODE")
	private String locationCode;
	
	@Column(name = "SHIPTO_CODE")
	private String shipToCode;
	
	@Column(name = "SHIPTO_NAME")
	private String shipToName;
	
}
