package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.MonthSalesDto;
import com.cpc.channel.partner.connect.dto.SalesTrendsDto;
import com.cpc.channel.partner.connect.dto.TradeSalesDto;
import com.cpc.channel.partner.connect.dto.UserRequestDetailsDto;
import com.cpc.channel.partner.connect.dto.ViewSalesReportDto;

import java.time.LocalDateTime;
import java.util.List;


public interface TradeSalesService {

    List<TradeSalesDto> getTradeSales(String sapCode, LocalDateTime currentDate);

    TradeSalesDto getSalesStats(String sapCode, LocalDateTime currentDate);
    
    List<SalesTrendsDto> getSalesTrendsDetails(String sapCode, int noOfMonths);
    
    MonthSalesDto getMonthSalesDetails(String sapCode, LocalDateTime currentDate);

    List<ViewSalesReportDto> getSalesReportDetails(UserRequestDetailsDto salesReportRequest);
}
