package com.cpc.channel.partner.connect.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceDetails {
	
	private String invoiceNumber;
	private double invoiceQuantity;
}
