package com.cpc.channel.partner.connect.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NtProductMasterDto {
	
	private int productMasterId;
	
	private String ntProductCode;
	
	private String ntProductName;
	
	private String categoryName;
		
	private List<ProductSkuDetailsDto> productSkuList;
}
