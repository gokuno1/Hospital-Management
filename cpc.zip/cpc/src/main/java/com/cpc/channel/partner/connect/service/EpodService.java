package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.BaseDto;

public interface EpodService {

    BaseDto submitEpod(String orderId, String sapCode, String segmentCode);
}
