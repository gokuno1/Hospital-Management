package com.cpc.channel.partner.connect.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "feedback_master")
@Data
public class FeedbackMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FEEDBACK_MASTER_ID")
    private long ratingId;

    private String feedback;
}
