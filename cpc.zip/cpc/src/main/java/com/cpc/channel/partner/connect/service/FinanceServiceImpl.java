package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.CashDiscountDto;
import com.cpc.channel.partner.connect.dto.FinanceDto;
import com.cpc.channel.partner.connect.dto.FinancePaymentDto;
import com.cpc.channel.partner.connect.model.CashDiscount;
import com.cpc.channel.partner.connect.model.Finance;
import com.cpc.channel.partner.connect.repository.CashDiscountRepository;
import com.cpc.channel.partner.connect.repository.FinancePaymentRepository;
import com.cpc.channel.partner.connect.repository.FinanceRepository;

import lombok.RequiredArgsConstructor;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FinanceServiceImpl implements FinanceService {

    private final FinanceRepository financeRepository;

    private final DozerBeanMapper mapper;

    private final FinancePaymentRepository financePaymentRepository;

    private final CashDiscountRepository cashDiscountRepository;

    private static <T, U> List<U> listMap(Mapper mapper, List<T> source, Class<U> destType) {
        List<U> dest = new ArrayList<>();
        source.stream().forEach(element -> dest.add(mapper.map(element, destType)));
        return dest;
    }

    @Override
    public FinanceDto getFinanceStats(String sapCode){
        Finance user = financeRepository.findBySapCode(sapCode).orElse(new Finance());
        FinanceDto stats = new FinanceDto();
        stats.setSapCode(sapCode);
        stats.setCreditLimit(user.getCreditLimit());
        stats.setOutstandingAmount(user.getOutstandingAmount());
        stats.setAvailableCredit(user.getAvailableCredit());
        stats.setBalance(user.getBalance());
        double utilizedPercent = ((user.getCreditLimit()-user.getOutstandingAmount())/user.getCreditLimit())*100;
        stats.setUtilizedPercentage(utilizedPercent);
        stats.setMinimumAmount(user.getOutstandingAmount());
        return stats;

    }

    @Override
    public List<FinancePaymentDto> getFinancePaymentList(String sapCode){
        return listMap(mapper, financePaymentRepository.findBySapCode(sapCode), FinancePaymentDto.class);
    }

    @Override
    public CashDiscountDto getCashDiscount(String sapCode, LocalDateTime date){
    	CashDiscountDto response;
    	var fromDate = date.with(TemporalAdjusters.firstDayOfMonth());
    	fromDate = fromDate.with(ChronoField.NANO_OF_DAY, LocalTime.MIN.toNanoOfDay());
		var toDate = date.with(TemporalAdjusters.lastDayOfMonth());
		toDate = toDate.with(ChronoField.NANO_OF_DAY, LocalTime.MAX.toSecondOfDay());
        var cash = cashDiscountRepository.findBySapCodeAndDiscountDateBetween(sapCode, fromDate, toDate).orElse(new CashDiscount());
        response = mapper.map(cash, CashDiscountDto.class);
        response.setMaxEligibleDiscount(Double.toString(cash.getMaxEligibleDiscount()));
        response.setAvailedDiscount(Double.toString(cash.getAvailedDiscount()));
        response.setLostDiscount(Double.toString(cash.getLostDiscount()));
        return response;
    }



}
