package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.BaseDto;
import com.cpc.channel.partner.connect.dto.UserLoginRequest;
import com.cpc.channel.partner.connect.dto.UserLoginResponse;
import com.cpc.channel.partner.connect.model.AppUser;
import com.cpc.channel.partner.connect.repository.AppUserRepository;
import com.cpc.channel.partner.connect.utils.CpcConstants;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

import org.dozer.DozerBeanMapper;
import static org.springframework.http.HttpStatus.*;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class HomeServiceImpl implements UserService {

    private final AppUserRepository appUserRepository;

    private final DozerBeanMapper mapper;

    public AppUser getUser(long id) {
        return appUserRepository.findById(id).orElseThrow(RuntimeException::new);

    }
    
	@Override
	public BaseDto login(UserLoginRequest userCredentials) {
		log.info("Inside login method");
		BaseDto userResponse = new BaseDto();
		Optional<AppUser> user = appUserRepository.findByMobileNo(userCredentials.getUserMobileNo());
		if(user.isPresent()) {
			if(user.get().isActive()) {
				log.info("User valid");
				userResponse.setResponseMessage("OTP has been sent successfully to the user");
				userResponse.setStatus(OK.value());
			}else {
				log.info("User invalid");
				userResponse.setResponseMessage("Mobile number is not registered. Please contact to your sales team.");
				userResponse.setStatus(NOT_FOUND.value());
			}
		}else {
			userResponse.setResponseMessage("Mobile number is not registered. Please contact to your sales team.");
			userResponse.setStatus(NOT_FOUND.value());
		}
		return userResponse;
	}
	
	@Override
	public UserLoginResponse authenticateUser(UserLoginRequest userCredentials) {
		UserLoginResponse userResponse = new UserLoginResponse();
		if(CpcConstants.OTP.equalsIgnoreCase(userCredentials.getUserOtp())) {
			AppUser user = appUserRepository.findByMobileNo(userCredentials.getUserMobileNo()).orElse(new AppUser());
			userResponse = mapper.map(user, UserLoginResponse.class);
			userResponse.setResponseMessage("User authenticated successfully");
			userResponse.setStatus(OK.value());
		}else {
			userResponse.setResponseMessage("OTP is invalid. Please enter valid OTP");
			userResponse.setStatus(UNAUTHORIZED.value());
		}
		return userResponse;
	}
}
