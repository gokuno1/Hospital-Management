package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.ListResponse;
import com.cpc.channel.partner.connect.dto.PlaceOrderResponse;
import com.cpc.channel.partner.connect.dto.TradeOrderDto;
import com.cpc.channel.partner.connect.dto.TradeOrderResponse;

public interface TradeService {

    PlaceOrderResponse placeOrder(TradeOrderDto tradeOrderDto);

    ListResponse<TradeOrderResponse> getOrders(String segmentCode, String sapCode, String orderStatus, String filterBy, int pageNo);

    TradeOrderDto getOrder(String sapOrderId,String sapCode);

}
