package com.cpc.channel.partner.connect.controller;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cpc.channel.partner.connect.dto.BaseDto;
import com.cpc.channel.partner.connect.dto.UserLoginRequest;
import com.cpc.channel.partner.connect.dto.UserLoginResponse;
import com.cpc.channel.partner.connect.service.UserService;
import com.cpc.channel.partner.connect.utils.ResponseUtils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
@Slf4j
public class UserController {

	private final UserService userService;
	
	@PostMapping("/login")
    public ResponseEntity<BaseDto> userLogin(@Valid @RequestBody UserLoginRequest loginRequest) {
		log.info("Inside Login");
		BaseDto loginResponse = userService.login(loginRequest);
		log.info("After Login");
		return ResponseEntity.ok(loginResponse);
    }
	
	@PostMapping("/authenticate")
    public ResponseEntity<UserLoginResponse> authenticateUser(@Valid @RequestBody UserLoginRequest loginRequest) {
		UserLoginResponse loginResponse = userService.authenticateUser(loginRequest);
		if(HttpStatus.OK.value()==loginResponse.getStatus()) {
			return ResponseEntity.ok(loginResponse);
		}else {
			return ResponseUtils.getUnAuthorizedResponse(loginResponse);
		}
		
    }
	
}
