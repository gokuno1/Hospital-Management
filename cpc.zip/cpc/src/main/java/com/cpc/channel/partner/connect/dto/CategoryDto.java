package com.cpc.channel.partner.connect.dto;

public interface CategoryDto {

	int getCategoryId();
	String getCategoryName();
}
