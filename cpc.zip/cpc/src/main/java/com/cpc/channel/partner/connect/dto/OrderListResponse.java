package com.cpc.channel.partner.connect.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderListResponse {

	private String sapCode;
	private String sapOrderId;
	private LocalDateTime deliveryDate;
	private String deliveryTimeSlot;
	private String shipToCode;
	private String shipToName;
	private String orderStatus;
	private String specialInstructions;
	private LocalDateTime orderPlacedDate;
	private LocalDateTime acknowledgedDate;
	private String invoiceNo;
    private LocalDateTime invoiceDate;
	private boolean ePod;
    private boolean feedback;
	private List<CartDto> orderSkus;
	private String vehicleNo;
	private DeliveryAddressDto address;
}
