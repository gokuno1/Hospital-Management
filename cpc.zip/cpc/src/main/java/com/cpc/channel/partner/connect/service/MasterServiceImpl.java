package com.cpc.channel.partner.connect.service;

import java.util.List;
import java.util.stream.Collectors;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.stereotype.Service;

import com.cpc.channel.partner.connect.dto.AddressPincodeDetailsDto;
import com.cpc.channel.partner.connect.dto.CategoryDto;
import com.cpc.channel.partner.connect.dto.CityPincodeDetailsDto;
import com.cpc.channel.partner.connect.dto.DeliveryAddressDto;
import com.cpc.channel.partner.connect.dto.DeliveryDetailsDto;
import com.cpc.channel.partner.connect.dto.LocationShipToDetailsDto;
import com.cpc.channel.partner.connect.dto.NormalProductMasterDto;
import com.cpc.channel.partner.connect.dto.NtProductMasterDto;
import com.cpc.channel.partner.connect.dto.ProductMasterDto;
import com.cpc.channel.partner.connect.dto.ProductRequest;
import com.cpc.channel.partner.connect.dto.ProductSkuDetailsDto;
import com.cpc.channel.partner.connect.dto.TimeSlotDetailsDto;
import com.cpc.channel.partner.connect.dto.UserSegmentDto;
import com.cpc.channel.partner.connect.model.NtProductMaster;
import com.cpc.channel.partner.connect.model.ShipToPincodeDetails;
import com.cpc.channel.partner.connect.repository.CityPincodeDetailsRepository;
import com.cpc.channel.partner.connect.repository.DeliveryAddressRepository;
import com.cpc.channel.partner.connect.repository.LocationShipToDetailsRepository;
import com.cpc.channel.partner.connect.repository.NtProductMasterRepository;
import com.cpc.channel.partner.connect.repository.ProductMasterRepository;
import com.cpc.channel.partner.connect.repository.ShipToPincodeDetailsRepository;
import com.cpc.channel.partner.connect.repository.TimeSlotDetailsRepository;
import com.cpc.channel.partner.connect.repository.UserSegmentRepository;

import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;

@Service
@RequiredArgsConstructor
public class MasterServiceImpl implements MasterService{
	
	private final LocationShipToDetailsRepository locationShipToDetailsRepository;
	
	private final TimeSlotDetailsRepository timeSlotDetailsRepository;
	
	private final NtProductMasterRepository ntProductMasterRepository;
	
	private final ProductMasterRepository productMasterRepository;
	
	private final UserSegmentRepository userSegmentRepository;
	
	private final ShipToPincodeDetailsRepository shipToPincodeDetailsRepository;
	
	private final DeliveryAddressRepository deliveryAddressRepository;
	
	private final CityPincodeDetailsRepository cityPincodeDetailsRepository;
	
	private final DozerBeanMapper mapper;
	
	private static <T, U> List<U> listMap(Mapper mapper, List<T> source, Class<U> destType) {
        List<U> dest = new ArrayList<>();
        source.stream().forEach(element -> dest.add(mapper.map(element, destType)));
        return dest;
    }

	@Override
	public DeliveryDetailsDto getDeliveryDetails(String sapcode, String locationCode) {
		DeliveryDetailsDto deliveryDetailsResponse = new DeliveryDetailsDto();
		List<LocationShipToDetailsDto> shipToDetails = listMap(mapper, locationShipToDetailsRepository.findByLocationCode(locationCode), LocationShipToDetailsDto.class);
		List<TimeSlotDetailsDto> timeSlotDetails = listMap(mapper, timeSlotDetailsRepository.findAll(), TimeSlotDetailsDto.class);
		deliveryDetailsResponse.setLocationShipToDetails(shipToDetails);
		deliveryDetailsResponse.setTimeSlotDetails(timeSlotDetails);
		return deliveryDetailsResponse;
	}

	@Override
	public ProductMasterDto getProducts(ProductRequest productRequest) {
		
		ProductMasterDto productResponse = new ProductMasterDto();
		productResponse.setProductList(listMap(mapper, productMasterRepository.findAll(), NormalProductMasterDto.class));
		return productResponse;
	}

	@Override
	public ProductMasterDto getNtProducts(ProductRequest productRequest) {
		ProductMasterDto productResponse = new ProductMasterDto();
		List<NtProductMasterDto> productResponseList = new ArrayList<>();
		List<NtProductMaster> productList = ntProductMasterRepository.getProductsByCategory(productRequest.getProductCategory());
		List<String> productCodes = productList.stream().map(NtProductMaster::getNtProductCode).distinct().collect(Collectors.toList());
		HashMap<String, List<ProductSkuDetailsDto>> productSku = getProductWiseSkuDetails(productList);
		for(String productCode : productCodes) {
			NtProductMaster product = productList.stream().filter(p -> productCode.equals(p.getNtProductCode())).findFirst().orElse(new NtProductMaster());
			NtProductMasterDto ntProduct = mapper.map(product, NtProductMasterDto.class);
			ntProduct.setProductSkuList(productSku.get(product.getNtProductCode()));
			productResponseList.add(ntProduct);
		}
		productResponse.setNtProductList(productResponseList);
		return productResponse;
	}
	
	private HashMap<String, List<ProductSkuDetailsDto>> getProductWiseSkuDetails(List<NtProductMaster> productDetails){
		HashMap<String, List<ProductSkuDetailsDto>> productSku = new HashMap<>();
		for(NtProductMaster product : productDetails) {
			if(productSku.containsKey(product.getNtProductCode())) {
				var skuList = productSku.get(product.getNtProductCode());
				skuList.add(new ProductSkuDetailsDto(skuList.size()+1, product.getProductSku()));
				productSku.put(product.getNtProductCode(), skuList);
			}else {
				List<ProductSkuDetailsDto> skus = new ArrayList<>();
				skus.add(new ProductSkuDetailsDto(skus.size()+1, product.getProductSku()));
                productSku.put(product.getNtProductCode(), skus);
			}
		}
		return productSku;
	}

	@Override
	public List<UserSegmentDto> getUserSegments(String sapcode) {
		return listMap(mapper, userSegmentRepository.getSegmentBySapcode(sapcode), UserSegmentDto.class);
	}

	@Override
	public List<CategoryDto> getNtProductsCategory() {
		return ntProductMasterRepository.getNtProductCategory();
	}

	@Override
	public AddressPincodeDetailsDto getDeliveryAddress(String sapCode, String shipToCode) {
		AddressPincodeDetailsDto addressPincodeDetails = new AddressPincodeDetailsDto();
		List<ShipToPincodeDetails> shipToPincodeDetails = shipToPincodeDetailsRepository.findByShipToCode(shipToCode);
		List<String> pincodes = shipToPincodeDetails.stream().map(ShipToPincodeDetails::getPinCode).distinct().collect(Collectors.toList());
		addressPincodeDetails.setDeliveryAddressDto(listMap(mapper, deliveryAddressRepository.findBySapCodeAndPinCodeIn(sapCode, pincodes), DeliveryAddressDto.class));
		addressPincodeDetails.setCityPincodeDetails(listMap(mapper, cityPincodeDetailsRepository.getCityStateDetailsByPincodes(pincodes), CityPincodeDetailsDto.class));
		return addressPincodeDetails;
	}
	

}
