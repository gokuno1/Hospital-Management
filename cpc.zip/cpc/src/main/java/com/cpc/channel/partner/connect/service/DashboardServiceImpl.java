package com.cpc.channel.partner.connect.service;

import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cpc.channel.partner.connect.dto.OrderOverview;
import com.cpc.channel.partner.connect.model.OrderMasterCount;
import com.cpc.channel.partner.connect.model.OrderStatusCount;
import com.cpc.channel.partner.connect.repository.OrderMasterCountRepository;
import com.cpc.channel.partner.connect.repository.OrderStatusCountRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

	private final OrderMasterCountRepository orderMasterCountRepository;
	
	private final OrderStatusCountRepository orderStatusCountRepository;
	
	@Override
	public OrderOverview getDashboardOrderOverview(String sapCode, String segmentCode, LocalDateTime currentDate) {
		OrderOverview orderOverview = new OrderOverview();
		List<OrderMasterCount> getDispatchedCount = null;
		List<OrderStatusCount> getOrderCount = null;
		if("NT1001".equalsIgnoreCase(segmentCode)) {
			getOrderCount = orderStatusCountRepository.findOrderCountByStatus(sapCode, segmentCode, currentDate.with(TemporalAdjusters.firstDayOfMonth()), currentDate.with(TemporalAdjusters.lastDayOfMonth()));
			getDispatchedCount = orderMasterCountRepository.getOrderQuantityByDateForNtOrder(sapCode, currentDate.with(TemporalAdjusters.firstDayOfMonth()), currentDate.with(TemporalAdjusters.lastDayOfMonth()));
		}else {
			getOrderCount = orderStatusCountRepository.findOrderCountByStatus(sapCode, segmentCode, currentDate.with(TemporalAdjusters.firstDayOfMonth()), currentDate.with(TemporalAdjusters.lastDayOfMonth()));
			getDispatchedCount = orderMasterCountRepository.getOrderQuantityByDate(sapCode, segmentCode, 
					currentDate.with(TemporalAdjusters.firstDayOfMonth()), currentDate.with(TemporalAdjusters.lastDayOfMonth()));
		}		
		var pendingOrders = getOrderCount.stream().filter(d->d.getOrderStatus().equalsIgnoreCase("PENDING")).findFirst().orElse(new OrderStatusCount());
		var acknowledgedOrders = getOrderCount.stream().filter(d->d.getOrderStatus().equalsIgnoreCase("ACCEPTED") || d.getOrderStatus().equalsIgnoreCase("COMPLETED")).findFirst().orElse(new OrderStatusCount());
		var dispatchedToday = getDispatchedCount.stream().filter(d->d.getOrderPlacedDate().toLocalDate().equals(currentDate.toLocalDate())).findFirst(); 
		var dispatchedYesterday = getDispatchedCount.stream().filter(d->d.getOrderPlacedDate().toLocalDate().equals(currentDate.minusDays(1).toLocalDate())).findFirst();
		var dispatchedMtd = getDispatchedCount.stream().mapToDouble(OrderMasterCount::getOrderQuantity).sum();
		
		orderOverview.setDispatchedToday(dispatchedToday.isPresent()?dispatchedToday.get().getOrderQuantity():0.0);
		orderOverview.setDispatchedYesterday(dispatchedYesterday.isPresent()?dispatchedYesterday.get().getOrderQuantity():0.0);
		orderOverview.setDispatchedMtd(dispatchedMtd);
		orderOverview.setPending(pendingOrders.getOrderCount());
		orderOverview.setAcknowledged(acknowledgedOrders.getOrderCount());
		orderOverview.setOrderPlaced(pendingOrders.getOrderCount()+acknowledgedOrders.getOrderCount());
		return orderOverview;
	}

}
