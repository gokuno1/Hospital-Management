package com.cpc.channel.partner.connect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "month_sales")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MonthSalesDetails {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MONTH_SALES_ID")
	private int monthSalesId;
	
	@Column(name = "SAP_CODE")
	private String sapCode;
	
	@Column(name = "PREV_MONTH_SALES")
	private double prevMonthSales;
	
	@Column(name = "PREV_YEAR_SALES")
	private double prevYearSales;
	
	@Column(name = "CURRENT_MONTH_SALES")
	private double currentMonthSales;
	
	@Column(name = "MONTH_DATE")
	private String monthDetails;
}
