package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.NotificationDetailsDto;

import java.util.List;

public interface NotificationService {

    List<NotificationDetailsDto> getDetailsList(String sapCode);

    int getNotificationCount(String sapCode);
}
