package com.cpc.channel.partner.connect.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderOverview {

	private double orderPlaced;
	private double pending;
	private double acknowledged;
	private double dispatchedToday;
	private double dispatchedYesterday;
	private double dispatchedMtd;
}
