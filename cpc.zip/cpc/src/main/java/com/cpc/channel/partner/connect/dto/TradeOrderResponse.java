package com.cpc.channel.partner.connect.dto;

import lombok.Data;

import java.time.LocalDateTime;

import com.cpc.channel.partner.connect.model.DeliveryAddress;

@Data
public class TradeOrderResponse {

    private String sapOrderId;

    private String sapCode;

    private String segmentCode;

    private String segmentType;

    private String productCode;

    private String productDesc;

    private String vehicleType;

    private String vehicleNo;

    private String driverMobileNo;

    private double quantity;

    private LocalDateTime orderPlacedDate;

    private String deliveryTimeSlot;

    private LocalDateTime deliveryDate;

    private String specialInstructions;

    private LocalDateTime acknowledgedDate;

    private String orderStatus;

    private String shipToCode;

    private String shipToName;

    private String invoiceNo;

    private LocalDateTime invoiceDate;

    private String contactNo;

    private LocalDateTime eta;

    private boolean ePod;
    
    private boolean feedback;
    
    private DeliveryAddress address;

}
