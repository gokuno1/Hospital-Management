package com.cpc.channel.partner.connect.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CityPincodeDetailsDto {

    private long cityPincodeId;
	
	private String pinCodeDesc;

	private String pinCode;
	
	private String city;

    private String state;
	
}
