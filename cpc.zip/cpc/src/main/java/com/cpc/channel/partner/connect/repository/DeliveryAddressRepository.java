package com.cpc.channel.partner.connect.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cpc.channel.partner.connect.model.DeliveryAddress;

@Repository
public interface DeliveryAddressRepository extends JpaRepository<DeliveryAddress, Long> {


    List<DeliveryAddress> findBySapCodeAndPinCodeIn(String sapCode, List<String> pinCodes);

    @Query(value = "SELECT * FROM delivery_address_details where SAP_CODE=?1 and ADDRESS_LINE_1=?2 and ADDRESS_LINE_2=?3 and ADDRESS_LINE_3=?4 LIMIT 1",nativeQuery = true)
    Optional<DeliveryAddress> findByAddress(String sapCode, String addressLine1, String addressLine2, String addressLine3);


}
