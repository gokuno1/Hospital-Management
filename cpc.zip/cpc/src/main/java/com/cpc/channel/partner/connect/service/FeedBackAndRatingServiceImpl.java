package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.BaseDto;
import com.cpc.channel.partner.connect.dto.FeedbackAndRatingDto;
import com.cpc.channel.partner.connect.dto.FeedbackDto;
import com.cpc.channel.partner.connect.mapper.FeedbackMapper;
import com.cpc.channel.partner.connect.model.FeedbackMaster;
import com.cpc.channel.partner.connect.model.OrderMaster;
import com.cpc.channel.partner.connect.model.OrderRating;
import com.cpc.channel.partner.connect.repository.FeedbackMasterRepository;
import com.cpc.channel.partner.connect.repository.OrderMasterRepository;
import com.cpc.channel.partner.connect.repository.OrderRatingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;


@Service
@Slf4j
@RequiredArgsConstructor
public class FeedBackAndRatingServiceImpl implements FeedBackAndRatingService {

    private final FeedbackMasterRepository feedbackMasterRepository;

    private final FeedbackMapper feedbackMapper;

    private final OrderRatingRepository orderRatingRepository;

    private final OrderMasterRepository orderMasterRepository;


    @Override
    public List<FeedbackDto> getFeedback() {
        log.info("FeedBackAndRatingServiceImpl.getFeedback");
        List<FeedbackMaster> feedbackMasters = feedbackMasterRepository.findAll();
        return feedbackMasters.stream().map(feedbackMapper::modelToDto).collect(Collectors.toList());
    }


    @Override
    public BaseDto saveRating(FeedbackAndRatingDto ratingDto) {
        OrderMaster orderMaster = orderMasterRepository.findBySapOrderIdAndSapCode(ratingDto.getSapOrderId(), ratingDto.getSapCode());
        OrderRating orderRating = feedbackMapper.ratingDtoToModel(ratingDto);
        orderMaster.setFeedback(true);
        orderRating.setOrderMaster(orderMaster);
        orderRating.setRatedDate(LocalDateTime.now());
        OrderRating rating = orderRatingRepository.save(orderRating);
        log.info(" your ratings have been save {} ", rating);
        BaseDto response = new BaseDto();
        response.setResponseMessage("Your Feedback and Rating Submitted Successfully for the Order #" + ratingDto.getSapOrderId());
        response.setStatus(HttpStatus.CREATED.value());
        return response;

    }
}
