package com.cpc.channel.partner.connect.repository;

import com.cpc.channel.partner.connect.dto.OrderProjectionDto;
import com.cpc.channel.partner.connect.dto.ProductWiseSalesDto;
import com.cpc.channel.partner.connect.model.OrderMaster;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderMasterRepository extends JpaRepository<OrderMaster, Long> {

    @Query(value = "select o from OrderMaster o JOIN o.address JOIN o.orderSkus where o.sapCode=?1 and o.segmentCode=?2 and o.orderStatus in ?3 order by o.orderPlacedDate desc")
    List<OrderMaster> findBySapCodeAndSegmentCodeAndOrderStatusIn(String sapCode, String segmentCode, List<String> orderStatus);

    @Query(value = "From OrderMaster o join fetch o.address  where o.segmentCode =:segmentCode and o.sapCode =:sapCode and o.orderStatus in ('ACCEPTED', 'ACKNOWLEDGED', 'PENDING', 'REJECTED') order by o.orderPlacedDate desc"/*, countQuery = "select count(*) From OrderMaster where segmentCode =: segmentCode and  sapCode =:sapCode and orderStatus in ('ACCEPTED', 'ACKNOWLEDGED', 'PENDING', 'REJECTED')"*/)
    List<OrderMaster> findOnGoingOrders(@Param("segmentCode") String segmentCode, @Param("sapCode") String sapCode/*, Pageable pageable*/);

    @Query(value = "From OrderMaster o join fetch o.address where o.segmentCode =:segmentCode and o.sapCode =:sapCode and o.orderStatus in ('COMPLETED', 'CONFIRMED', 'DELIVERED') order by o.orderPlacedDate desc", countQuery = "select count(*) From OrderMaster where segmentCode =:segmentCode and  sapCode =:sapCode and orderStatus in ('COMPLETED', 'CONFIRMED', 'DELIVERED')")
    List<OrderMaster> findDispatchedOrders(@Param("segmentCode") String segmentCode, @Param("sapCode") String sapCode/*, Pageable pageable*/);

    @Query(value = "From OrderMaster o join fetch o.address where o.segmentCode =:segmentCode and o.sapCode =:sapCode and o.ePod= :ePod and o.orderStatus in ('COMPLETED', 'CONFIRMED', 'DELIVERED') order by o.orderPlacedDate desc", countQuery = "select count(*) From OrderMaster where segmentCode =:segmentCode and  sapCode =:sapCode and ePod=:ePod and orderStatus in ('COMPLETED', 'CONFIRMED', 'DELIVERED')")
    List<OrderMaster> findDispatchedOrders(@Param("segmentCode") String segmentCode, @Param("sapCode") String sapCode, @Param("ePod") boolean ePod/*, Pageable pageable*/);

    @Query(value = "From OrderMaster o join fetch o.address where o.sapOrderId =:sapOrderId and o.sapCode =:sapCode")
    OrderMaster findBySapOrderIdAndSapCode(String sapOrderId, String sapCode);

//   By using order projection interface
//   @Query(value = "select SAP_ORDER_ID as sapOrderId, INVOICE_NO as invoiceNo, ORDER_QUANTITY as quantity, ORDER_PLACED_DATE as orderPlacedDate from order_master where SAP_CODE=?1 and SEGMENT_CODE=?2 and ORDER_STATUS=?3 and ORDER_PLACED_DATE between ?3 and ?4",nativeQuery = true)
//   List<OrderProjection> findAllBySapCodeAndSegmentCodeAndOrderStatusAndOrderPlacedDateBetween(String sapCode, String segmentCode, String orderStatus, LocalDateTime fromDate, LocalDateTime toDa

    @Query(value = "select new com.cpc.channel.partner.connect.dto.OrderProjectionDto(sapOrderId,quantity,invoiceNo,orderPlacedDate) from OrderMaster where sapCode=?1 and segmentCode=?2 and orderStatus='COMPLETED' and orderPlacedDate between ?3 and ?4")
    List<OrderProjectionDto> findAllOrderDetails(String sapCode, String segmentCode, LocalDateTime fromDate, LocalDateTime toDate);

    @Query(value = "select product_code as productCode, SUM(order_quantity) as quantity from order_master where SAP_CODE = ?1 and ORDER_PLACED_DATE between ?2 and ?3 and product_code is not null group by PRODUCT_DESC",nativeQuery = true)
    List<ProductWiseSalesDto> findProductsBySapCodeAndProductCodeAndBetweenOrderDate(String sapCode, LocalDateTime fromDate, LocalDateTime toDate);

    @Modifying
    @Query(value = "UPDATE OrderMaster o SET o.ePod= true, o.deliveryConfirmationDate = ?3 where o.sapOrderId = ?1 and o.sapCode = ?2")
    void updateEpodStatus(String sapOrderId, String sapCode, LocalDateTime dateTime);

}
