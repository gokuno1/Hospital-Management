package com.cpc.channel.partner.connect.dto;

public interface ProductWiseSalesDto {

	  String getProductCode();
	  double getQuantity();
}
