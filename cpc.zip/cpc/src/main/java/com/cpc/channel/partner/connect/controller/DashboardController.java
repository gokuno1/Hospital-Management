package com.cpc.channel.partner.connect.controller;

import java.time.LocalDateTime;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cpc.channel.partner.connect.dto.OrderOverview;
import com.cpc.channel.partner.connect.service.DashboardService;
import com.cpc.channel.partner.connect.utils.ResponseUtils;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/dashboard")
public class DashboardController {

	private final DashboardService dashboardService;

	@GetMapping("/order-overview")
    public ResponseEntity<OrderOverview> getOrderOverview(@RequestHeader String sapCode, 
    													  @RequestHeader String segmentCode,
    													  @RequestHeader String currentDate) {
		OrderOverview dashboardResponse = dashboardService.getDashboardOrderOverview(sapCode, segmentCode, LocalDateTime.parse(currentDate));
		return ResponseUtils.getOKResponse(dashboardResponse);
		
    }
}
