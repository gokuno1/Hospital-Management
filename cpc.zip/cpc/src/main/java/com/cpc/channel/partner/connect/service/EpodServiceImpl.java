package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.BaseDto;
import com.cpc.channel.partner.connect.repository.OrderMasterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class EpodServiceImpl implements EpodService {

    private final OrderMasterRepository orderMasterRepository;

    @Transactional
    @Override
    public BaseDto submitEpod(String sapOrderId, String sapCode, String segmentCode) {
        orderMasterRepository.updateEpodStatus(sapOrderId,sapCode, LocalDateTime.now());
        return new BaseDto("EPOD done successfully", HttpStatus.OK.value());
    }
}
