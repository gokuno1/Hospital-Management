package com.cpc.channel.partner.connect.controller;

import com.cpc.channel.partner.connect.dto.SalesReportDto;
import com.cpc.channel.partner.connect.service.SalesReportService;
import lombok.RequiredArgsConstructor;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/salesreport")
@RequiredArgsConstructor
public class SalesReportController {

    private final SalesReportService salesReportService;


    @GetMapping("/")
    public ResponseEntity<List<SalesReportDto>> getSalesReport(@RequestHeader(name = "sapCode") String sapCode,
    														   @RequestHeader(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime currentDate,
    														   @RequestHeader(required = false) String segmentCode){
        List<SalesReportDto> salesList = salesReportService.getSalesReport(sapCode, currentDate);
        return ResponseEntity.ok(salesList);
    }

}
