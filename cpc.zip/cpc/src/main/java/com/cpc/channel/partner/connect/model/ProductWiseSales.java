package com.cpc.channel.partner.connect.model;

public interface ProductWiseSales {

    public String getSapCode();

    public String getProductCode();

    public double getQuantity();
}
