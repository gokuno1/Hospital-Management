package com.cpc.channel.partner.connect.repository;

import com.cpc.channel.partner.connect.model.FeedbackMaster;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeedbackMasterRepository extends CrudRepository<FeedbackMaster, Long> {

    List<FeedbackMaster> findAll();


}
