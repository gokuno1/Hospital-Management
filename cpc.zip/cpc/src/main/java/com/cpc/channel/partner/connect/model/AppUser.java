package com.cpc.channel.partner.connect.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

import javax.persistence.*;

@Entity
@Table(name = "user_master")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_MASTER_ID")
    private long userId;

    @Column(name = "SAP_CODE")
    private String sapCode;
    
    @Column(name = "NAME")
    private String username;
    
    @Column(name = "COMPANY_NAME")
    private String companyName;
    
    @Column(name = "MOBILE_NO")
    private String mobileNo;
    
    @Column(name = "DESIGNATION")
    private String designation;
    
    @Column(name = "IS_ACTIVE")
    private boolean isActive;
    
    @Column(name = "ADDRESS_LINE_1")
    private String addressLine1;
    
    @Column(name = "ADDRESS_LINE_2")
    private String addressLine2;
    
    @Column(name = "ADDRESS_LINE_3")
    private String addressLine3;
    
    @Column(name = "CITY")
    private String city;
    
    @Column(name = "PINCODE")
    private String 	pinCode;
    
    @Column(name = "LOCATION_CODE")
    private String locationCode;
    
    @Column(name = "CREATED_DATE")
    private LocalDateTime createdDate;
    
    @Column(name = "UPDATED_DATE")
    private LocalDateTime updatedDate;
}
