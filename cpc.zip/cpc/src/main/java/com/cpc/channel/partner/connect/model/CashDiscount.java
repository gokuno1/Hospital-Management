package com.cpc.channel.partner.connect.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "cash_discount")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CashDiscount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private long cashDiscountId;

    @Column(name = "SAP_CODE")
    private String sapCode;

    @Column(name = "MAX_ELIGIBLE_DISCOUNT")
    private double maxEligibleDiscount;

    @Column(name = "AVAILED_DISCOUNT")
    private double availedDiscount;

    @Column(name = "LOST_DISCOUNT")
    private double lostDiscount;

    @Column(name = "DISCOUNT_DATE")
    private LocalDateTime discountDate;

}
