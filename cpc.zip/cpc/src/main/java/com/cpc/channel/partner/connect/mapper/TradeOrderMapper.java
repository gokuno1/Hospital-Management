package com.cpc.channel.partner.connect.mapper;

import com.cpc.channel.partner.connect.dto.TradeOrderDto;
import com.cpc.channel.partner.connect.model.OrderMaster;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface TradeOrderMapper {

	TradeOrderDto modelToDto(OrderMaster orderMaster);

    OrderMaster dtoToModel(TradeOrderDto orderDto);
}
