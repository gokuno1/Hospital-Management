package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.InvoiceDetails;
import com.cpc.channel.partner.connect.dto.MonthSalesDto;
import com.cpc.channel.partner.connect.dto.OrderProjectionDto;
import com.cpc.channel.partner.connect.dto.SalesTrendsDto;
import com.cpc.channel.partner.connect.dto.TradeSalesDto;
import com.cpc.channel.partner.connect.dto.UserRequestDetailsDto;
import com.cpc.channel.partner.connect.dto.ViewSalesReportDto;
import com.cpc.channel.partner.connect.model.MonthSalesDetails;
import com.cpc.channel.partner.connect.model.OrderMaster;
import com.cpc.channel.partner.connect.model.SalesTrends;
import com.cpc.channel.partner.connect.model.TradeSales;
import com.cpc.channel.partner.connect.repository.MonthSalesDetailsRepository;
import com.cpc.channel.partner.connect.repository.OrderMasterRepository;
import com.cpc.channel.partner.connect.repository.SalesTrendsDetailsRepository;
import com.cpc.channel.partner.connect.repository.TradeSalesRepository;
import lombok.RequiredArgsConstructor;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TradeSalesImpl implements TradeSalesService {


    private final TradeSalesRepository tradeSalesRepository;
    
    private final MonthSalesDetailsRepository monthSalesDetailsRepository;
    
    private final SalesTrendsDetailsRepository salesTrendsDetailsRepository;
    
    private final OrderMasterRepository orderMasterRepository;

    private final DozerBeanMapper mapper;

    private static <T, U> List<U> listMap(Mapper mapper, List<T> source, Class<U> destType) {
        List<U> dest = new ArrayList<>();
        source.stream().forEach(element -> dest.add(mapper.map(element, destType)));
        return dest;
    }

    @Override
    public List<TradeSalesDto> getTradeSales(String sapCode, LocalDateTime currentDate) {
        return listMap(mapper, tradeSalesRepository.findBySapCode(sapCode, currentDate.with(TemporalAdjusters.firstDayOfMonth()), currentDate.with(TemporalAdjusters.lastDayOfMonth())), TradeSalesDto.class);
    }

    @Override
    public TradeSalesDto getSalesStats(String sapCode, LocalDateTime currentDate){
    	TradeSalesDto tradeSalesResponse = new TradeSalesDto();
        TradeSales tradeSalesList = tradeSalesRepository.findBySapCodeAndOrderPlacedDate(sapCode, currentDate.with(TemporalAdjusters.firstDayOfMonth()), currentDate.with(TemporalAdjusters.lastDayOfMonth()));
        double askingRate = 0;
        Calendar calendar = Calendar.getInstance();
        int lastDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        int firstDay = calendar.getActualMinimum(Calendar.DAY_OF_MONTH);
        int currentDay = calendar.get(Calendar.DAY_OF_MONTH);
        int daysLeft = lastDay - currentDay;
        int daysCompleted = currentDay-firstDay;
        if(tradeSalesList!=null) {
        	askingRate = tradeSalesList.getTargetQuantity() + ( (tradeSalesList.getTargetQuantity()-tradeSalesList.getAchievedQuantity()) / daysCompleted );
        	tradeSalesResponse = mapper.map(tradeSalesList, TradeSalesDto.class);
        }
        tradeSalesResponse.setCurrentMonthTargetDays(daysLeft);
        tradeSalesResponse.setAskingRate(Math.floor(askingRate));
        return tradeSalesResponse;
    }

	@Override
	public List<SalesTrendsDto> getSalesTrendsDetails(String sapCode, int noOfMonths) {
		List<SalesTrends> monthWiseSales = salesTrendsDetailsRepository.getMonthWiseSalesDetails(sapCode, noOfMonths);
		return listMap(mapper, monthWiseSales, SalesTrendsDto.class);
	}

	@Override
	public MonthSalesDto getMonthSalesDetails(String sapCode, LocalDateTime currentDate) {
		MonthSalesDto monthSalesResponse = new MonthSalesDto();
		Optional<MonthSalesDetails> monthSales = monthSalesDetailsRepository.getMonthSalesDetails(sapCode, currentDate.with(TemporalAdjusters.firstDayOfMonth()));
		if(monthSales.isPresent()) {
			monthSalesResponse = mapper.map(monthSales.get(), MonthSalesDto.class);
			double prevMonthChange = ((monthSales.get().getCurrentMonthSales()-monthSales.get().getPrevMonthSales())/monthSales.get().getCurrentMonthSales())*100;
			double prevYearChange = ((monthSales.get().getCurrentMonthSales()-monthSales.get().getPrevYearSales())/monthSales.get().getCurrentMonthSales())*100;
			monthSalesResponse.setPrevMonthPercentage(Math.floor(prevMonthChange));
			monthSalesResponse.setPrevYearPercentage(Math.floor(prevYearChange));
		}
		return monthSalesResponse;
	}

	@Override
	public List<ViewSalesReportDto> getSalesReportDetails(UserRequestDetailsDto salesReportRequest) {
		List<ViewSalesReportDto> salesReportData = new ArrayList<>();
		var firstDay = salesReportRequest.getInputDate().with(TemporalAdjusters.firstDayOfMonth());
		var lastDayofMonth = salesReportRequest.getInputDate().with(TemporalAdjusters.lastDayOfMonth());
		List<OrderProjectionDto> findAllBySapCode = orderMasterRepository.findAllOrderDetails(salesReportRequest.getSapCode(), 
				salesReportRequest.getSegmentCode(), firstDay, lastDayofMonth);
		var salesData = listMap(mapper, findAllBySapCode, OrderMaster.class);
		var getOrderInvoiceDetails = getOrderWiseInvoiceDetails(salesData);
		List<String> orderIds = salesData.stream().map(OrderMaster::getSapOrderId).distinct().collect(Collectors.toList());
		for(String orderId:orderIds) {
			ViewSalesReportDto reportDto = new ViewSalesReportDto();
			OrderMaster orderData = salesData.stream().filter(p -> orderId.equals(p.getSapOrderId())).findFirst().orElse(new OrderMaster());
			var orderInvoice = getOrderInvoiceDetails.get(orderId);
			reportDto.setSapOrderId(orderId);
			reportDto.setOrderDate(orderData.getOrderPlacedDate());
			reportDto.setInvoiceCount(orderInvoice.size());
			reportDto.setInvoiceDetails(orderInvoice);
			reportDto.setTotalQuantity(orderInvoice.stream().mapToDouble(InvoiceDetails::getInvoiceQuantity).sum());
			salesReportData.add(reportDto);
		}
		return salesReportData;
	}
	
	private HashMap<String, List<InvoiceDetails>> getOrderWiseInvoiceDetails(List<OrderMaster> orderDetails){
		HashMap<String, List<InvoiceDetails>> invoiceDetailsResponse = new HashMap<>();
		for(OrderMaster order : orderDetails) {
			if(invoiceDetailsResponse.containsKey(order.getSapOrderId())) {
				invoiceDetailsResponse.get(order.getSapOrderId()).add(new InvoiceDetails(order.getInvoiceNo(), order.getQuantity()));
			}else {
				List<InvoiceDetails> invoices = new ArrayList<>();
				invoices.add(new InvoiceDetails(order.getInvoiceNo(), order.getQuantity()));
                invoiceDetailsResponse.put(order.getSapOrderId(), invoices);
			}
		}
		return invoiceDetailsResponse;
	}

}
