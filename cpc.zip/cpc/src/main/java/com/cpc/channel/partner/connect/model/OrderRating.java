package com.cpc.channel.partner.connect.model;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "order_rating")
@Data
public class OrderRating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ORDER_RATING_ID")
    private long ratingId;

    @Column(name = "SAP_CODE")
    private String sapCode;

    @Column(name = "SAP_ORDER_ID")
    private String sapOrderId;

    @Column(name = "PRODUCT_QUANTITY")
    private int productQuantity;

    @Column(name = "DELIVERY_BEHAVIOUR")
    private int deliveryBehaviour;

    @Column(name = "DELIVERY_TIME")
    private int deliveryTime;

    @Column(name = "OVERALL_RATING")
    private int overallRating;

    private String feedback;

    @Column(name = "ADDITIONAL_COMMENTS")
    private String additionalComments;

    @Column(name = "RATED_DATE")
    private LocalDateTime ratedDate;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="ORDER_MASTER_ID")
    private OrderMaster orderMaster;


}
