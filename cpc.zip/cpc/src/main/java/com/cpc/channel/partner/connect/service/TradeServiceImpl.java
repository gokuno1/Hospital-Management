package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.ListResponse;
import com.cpc.channel.partner.connect.dto.PlaceOrderResponse;
import com.cpc.channel.partner.connect.dto.TradeOrderDto;
import com.cpc.channel.partner.connect.dto.TradeOrderResponse;
import com.cpc.channel.partner.connect.mapper.TradeOrderMapper;
import com.cpc.channel.partner.connect.model.DeliveryAddress;
import com.cpc.channel.partner.connect.model.OrderMaster;
import com.cpc.channel.partner.connect.repository.DeliveryAddressRepository;
import com.cpc.channel.partner.connect.repository.OrderMasterRepository;
import com.cpc.channel.partner.connect.utils.OrderUtils;

import lombok.RequiredArgsConstructor;
import org.dozer.DozerBeanMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TradeServiceImpl implements TradeService {

    private final OrderMasterRepository orderMasterRepository;

    private final DeliveryAddressRepository addressRepository;

    private final DozerBeanMapper mapper;

    private final TradeOrderMapper tradeOrderMapper;

    @Override
    @Transactional
    public PlaceOrderResponse placeOrder(TradeOrderDto tradeOrderDto) {
        String sapCode = tradeOrderDto.getSapCode();
        String orderId = OrderUtils.generateOrderId();
        var order = tradeOrderMapper.dtoToModel(tradeOrderDto);
        order.setSapOrderId(orderId);
        order.setOrderPlacedDate(LocalDateTime.now());
        order.setAcknowledgedDate(LocalDateTime.now());
        order.setSapCode(tradeOrderDto.getSapCode());
        order.setOrderStatus("ACCEPTED");
        order.setSegmentType("Trade");
        var address = order.getAddress();
        var optional = addressRepository.findByAddress(sapCode, address.getAddressLine1(), address.getAddressLine2(), address.getAddressLine3());
        DeliveryAddress deliveryAddress;
        if (optional.isPresent()) {
            deliveryAddress = optional.get();
        } else {
            deliveryAddress = mapper.map(address, DeliveryAddress.class);
            deliveryAddress.setSapCode(sapCode);
            deliveryAddress = addressRepository.save(deliveryAddress);
        }
        order.setAddress(deliveryAddress);
        var placedOrder = orderMasterRepository.save(order);
        var response = new PlaceOrderResponse();
        response.setOrderId(placedOrder.getSapOrderId());
        response.setResponseMessage("Your order has been placed successfully");
        response.setStatus(HttpStatus.CREATED.value());
        return response;
    }

    @Override
    public ListResponse<TradeOrderResponse> getOrders(String segmentCode, String sapCode, String orderStatus, String filterBy, int pageNo) {
        var listResponse = new ListResponse<TradeOrderResponse>();
        List<OrderMaster> orders = new ArrayList<>();
        if ("ONGOING".equalsIgnoreCase(orderStatus)) {
            orders = orderMasterRepository.findOnGoingOrders(segmentCode, sapCode);
            listResponse.setTotalCount(orders.size());
        } else if ("DISPATCHED".equalsIgnoreCase(orderStatus)) {
            if ("ALL".equalsIgnoreCase(filterBy)) {
                orders = orderMasterRepository.findDispatchedOrders(segmentCode, sapCode);
            } else {
                boolean ePod = "ePOD Done".equalsIgnoreCase(filterBy);
                orders = orderMasterRepository.findDispatchedOrders(segmentCode, sapCode, ePod);
            }
            listResponse.setTotalCount(orders.size());
        }
        var ordersDto = orders.stream().map(this::orderResponseMapper).collect(Collectors.toList());
        listResponse.setList(ordersDto);
        return listResponse;
    }

    @Override
    public TradeOrderDto getOrder(String sapOrderId, String sapCode) {
        OrderMaster byOrderIdAndSapCode = orderMasterRepository.findBySapOrderIdAndSapCode(sapOrderId, sapCode);
        return tradeOrderMapper.modelToDto(byOrderIdAndSapCode);
    }

    private TradeOrderResponse orderResponseMapper(OrderMaster order) {
        var orderDto = mapper.map(order, TradeOrderResponse.class);
        orderDto.setContactNo(order.getAddress().getContactNo());
        return orderDto;
    }

}
