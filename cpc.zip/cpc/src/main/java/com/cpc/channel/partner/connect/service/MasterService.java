package com.cpc.channel.partner.connect.service;

import java.util.List;

import com.cpc.channel.partner.connect.dto.AddressPincodeDetailsDto;
import com.cpc.channel.partner.connect.dto.CategoryDto;
import com.cpc.channel.partner.connect.dto.DeliveryDetailsDto;
import com.cpc.channel.partner.connect.dto.ProductMasterDto;
import com.cpc.channel.partner.connect.dto.ProductRequest;
import com.cpc.channel.partner.connect.dto.UserSegmentDto;

public interface MasterService {

	DeliveryDetailsDto getDeliveryDetails(String sapCode, String locationCode);
	
	ProductMasterDto getProducts(ProductRequest productRequest);
	
	ProductMasterDto getNtProducts(ProductRequest productRequest);
	
	List<UserSegmentDto> getUserSegments(String sapCode);
	
	List<CategoryDto> getNtProductsCategory();
	
	AddressPincodeDetailsDto getDeliveryAddress(String sapCode, String shipToCode);
	
}
