package com.cpc.channel.partner.connect.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SalesTrends {

	@Column(name = "CURRENT_MONTH_SALES")
	private double monthSales;
	
	@Id
	@Column(name = "MONTH_NAME")
	private LocalDateTime monthName;
	
}
