package com.cpc.channel.partner.connect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "city_pincode_mapping")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CityPincodeDetails {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CITY_PINCODE_ID")
    private long cityPincodeId;
	
	@Column(name = "PINCODE_DESC")
	private String pinCodeDesc;

	@Column(name = "PINCODE")
	private String pinCode;
	
	@Column(name = "CITY_NAME")
	private String city;

	@Column(name = "STATE")
    private String state;
}
