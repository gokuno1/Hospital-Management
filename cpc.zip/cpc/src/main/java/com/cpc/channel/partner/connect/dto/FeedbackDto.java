package com.cpc.channel.partner.connect.dto;

import lombok.Data;

@Data
public class FeedbackDto {

    private String feedback;
}
