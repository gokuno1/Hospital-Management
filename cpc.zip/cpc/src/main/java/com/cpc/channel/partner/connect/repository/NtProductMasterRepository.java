package com.cpc.channel.partner.connect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cpc.channel.partner.connect.dto.CategoryDto;
import com.cpc.channel.partner.connect.model.NtProductMaster;

@Repository
public interface NtProductMasterRepository extends JpaRepository<NtProductMaster, Integer> {
	
	@Query(value = "SELECT * FROM cpc_service.nt_product_master where CATEGORY_NAME=?1", nativeQuery = true)
	List<NtProductMaster> getProductsByCategory(String categoryName);
	
	@Query(value = "SELECT distinct CATEGORY_NAME as categoryName, (@row_number\\:=@row_number + 1) AS categoryId from cpc_service.nt_product_master,(SELECT @row_number\\:=0) as t group by CATEGORY_NAME", nativeQuery = true)
	List<CategoryDto> getNtProductCategory();

}
