package com.cpc.channel.partner.connect.dto;

import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;

@Data
public class FeedbackAndRatingDto {

    @NotBlank(message = "sapCode is mandatory")
    private String sapCode;

    @NotBlank(message = "OrderId is mandatory")
    private String sapOrderId;

    @Range(max = 5, message = "Rating should be in 0 to 5")
    private int productQuantity;

    @Range(max = 5, message = "Rating should be in 0 to 5")
    private int deliveryBehaviour;

    @Range(max = 5, message = "Rating should be in 0 to 5")
    private int deliveryTime;

    @Range(max = 5, message = "Rating should be in 0 to 5")
    private int overallRating;

    private String feedback;

    private String additionalComments;
}
