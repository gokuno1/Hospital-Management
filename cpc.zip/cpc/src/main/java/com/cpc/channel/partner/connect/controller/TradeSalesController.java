package com.cpc.channel.partner.connect.controller;

import com.cpc.channel.partner.connect.dto.*;
import com.cpc.channel.partner.connect.service.OrderService;
import com.cpc.channel.partner.connect.service.TradeSalesService;
import com.cpc.channel.partner.connect.utils.ListResponseVO;
import com.cpc.channel.partner.connect.utils.ResponseUtils;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/trade/sales")
@RequiredArgsConstructor
@Slf4j
public class TradeSalesController {

    private final TradeSalesService tradeSalesService;

    private final OrderService orderService;

    @GetMapping("")
    public ResponseEntity<List<TradeSalesDto>> getTradeSales(@RequestHeader(name = "sapCode") String sapCode,
    		@RequestHeader @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime currentDate){
        List<TradeSalesDto> users = tradeSalesService.getTradeSales(sapCode, currentDate);
        return ResponseEntity.ok(users);
    }

    @GetMapping("/overview")
    public ResponseEntity<TradeSalesDto> getTradeStats(@RequestHeader(name = "sapCode") String sapCode,
    		@RequestHeader @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime currentDate){
        TradeSalesDto stat = tradeSalesService.getSalesStats(sapCode, currentDate);
        return ResponseEntity.ok(stat);
    }
    
    @GetMapping("/trends")
    public ResponseEntity<ListResponseVO<SalesTrendsDto>> getSalesTrends(@RequestHeader String sapCode,
    																	 @RequestHeader int noOfMonths){
        List<SalesTrendsDto> salesTrends = tradeSalesService.getSalesTrendsDetails(sapCode, noOfMonths);
        ListResponseVO<SalesTrendsDto> salesTrendsResponse = new ListResponseVO<>();
        if(!salesTrends.isEmpty()) {
        	salesTrendsResponse.setList(salesTrends);
            salesTrendsResponse.setResponseMessage("Sales Trends Details");
        }
        return ResponseEntity.ok(salesTrendsResponse);
    }
    
    @GetMapping("/month")
    public ResponseEntity<MonthSalesDto> getMonthSales(@RequestHeader String sapCode,
    												   @RequestHeader @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime currentDate){
       log.info("Current date in request "+currentDate);
       MonthSalesDto monthSales = tradeSalesService.getMonthSalesDetails(sapCode, currentDate);
       if(monthSales!=null) {
    	   return ResponseUtils.getOKResponse(monthSales);
       }else{
    	   return ResponseUtils.getNotFoundResponse(monthSales);
       }
    }
    
    @PostMapping("/report")
	@Operation(description = "Get Sales report for current month")
	public ResponseEntity<ListResponseVO<ViewSalesReportDto>> getSalesDataList(@RequestBody UserRequestDetailsDto inputRequest){
		List<ViewSalesReportDto> orderList = tradeSalesService.getSalesReportDetails(inputRequest);
		ListResponseVO<ViewSalesReportDto> response = new ListResponseVO<>();
		response.setList(orderList);
		response.setResponseMessage("Sales Report");
		return ResponseUtils.getOKResponse(response);
	}

	@GetMapping("/product-wise")
    public ResponseEntity<ListResponseVO<ProductWiseSalesDto>> getSumofProductsAsPerMonth(@RequestHeader String sapCode,
    																					  @RequestHeader @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime currentDate){
        ListResponseVO<ProductWiseSalesDto> productsList = new ListResponseVO<>();
        var sumOfProductsAsPerMonth = orderService.getSumOfProductsAsPerMonth(sapCode, currentDate);
		productsList.setList(sumOfProductsAsPerMonth);
        productsList.setResponseMessage("Product wise sales");
        return ResponseEntity.ok(productsList);
    }

    

}
