package com.cpc.channel.partner.connect.utils;

public class CpcConstants {
	
	public static final String OTP = "123456";
	public static final String NO_DATA_FOUND = "No Data found";
	
}
