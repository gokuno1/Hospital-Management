package com.cpc.channel.partner.connect.repository;

import com.cpc.channel.partner.connect.model.CashDiscount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.Optional;

public interface CashDiscountRepository extends JpaRepository<CashDiscount,Long> {

    Optional<CashDiscount> findBySapCodeAndDiscountDateBetween(String sapCode, LocalDateTime fromDate, LocalDateTime toDate);
}
