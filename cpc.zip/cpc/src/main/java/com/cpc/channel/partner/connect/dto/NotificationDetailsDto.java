package com.cpc.channel.partner.connect.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationDetailsDto {


    private String sapCode;

    private String productName;

    private String invoiceNumber;

    private LocalDateTime orderPlacedDate;

    private String timeSlot;

    private String orderStatus;

}
