package com.cpc.channel.partner.connect.dto;


import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartDto {
	
	private long orderSkuId;
    private String sapCode;
    private String segmentCode;
    private String productCode;
    private String productName;
    private String category;
    private boolean placed;
    private int quantity;
    private String productSku;
    private Date createdDate;
}
