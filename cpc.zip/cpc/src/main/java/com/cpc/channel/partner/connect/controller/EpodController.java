package com.cpc.channel.partner.connect.controller;

import com.cpc.channel.partner.connect.dto.BaseDto;
import com.cpc.channel.partner.connect.service.EpodService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("orders/epod")
@RequiredArgsConstructor
public class EpodController {

    private final EpodService epodService;

    @PatchMapping
    public ResponseEntity<BaseDto> submitEpod(@RequestHeader String sapOrderId, @RequestHeader String sapCode,
                                                 @RequestHeader(required = false) String segmentCode) {

        BaseDto baseDto = epodService.submitEpod(sapOrderId, sapCode, segmentCode);
        return ResponseEntity.ok(baseDto);
    }
}
