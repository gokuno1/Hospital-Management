package com.cpc.channel.partner.connect.controller;


import com.cpc.channel.partner.connect.dto.NotificationDetailsDto;
import com.cpc.channel.partner.connect.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;


    @GetMapping("")
    public ResponseEntity<List<NotificationDetailsDto>> getDetails(@RequestHeader(name = "sapCode") String sapCode){
        List<NotificationDetailsDto> detailsDtoList = notificationService.getDetailsList(sapCode);
        return ResponseEntity.ok(detailsDtoList);
    }

    @GetMapping("/count")
    public ResponseEntity<Integer> getCount(@RequestHeader(name = "sapCode") String sapCode){
        int count = notificationService.getNotificationCount(sapCode);
        return ResponseEntity.ok(count);
    }
    

}
