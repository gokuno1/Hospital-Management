package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.BaseDto;
import com.cpc.channel.partner.connect.dto.UserLoginRequest;
import com.cpc.channel.partner.connect.dto.UserLoginResponse;

public interface UserService {

	BaseDto login(UserLoginRequest userCredentials);
	
	UserLoginResponse authenticateUser(UserLoginRequest userCredentials);

}
