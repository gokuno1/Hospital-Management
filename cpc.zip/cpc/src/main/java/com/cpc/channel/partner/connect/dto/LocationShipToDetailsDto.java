package com.cpc.channel.partner.connect.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LocationShipToDetailsDto {

	private int locationShipToId;
	private String locationCode;
	private String shipToCode;
	private String shipToName;
	
}
