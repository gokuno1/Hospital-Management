package com.cpc.channel.partner.connect.model;

import java.time.LocalDateTime;

public interface OrderProjection {

	public String getSapOrderId();
	
	public String getInvoiceNo();
	
	public String getQuantity();
	
	public LocalDateTime getOrderPlacedDate();
}
