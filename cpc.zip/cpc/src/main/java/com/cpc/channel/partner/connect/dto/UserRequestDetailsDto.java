package com.cpc.channel.partner.connect.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRequestDetailsDto {

	private String sapCode;
	private String segmentCode;
	private LocalDateTime inputDate;
}
