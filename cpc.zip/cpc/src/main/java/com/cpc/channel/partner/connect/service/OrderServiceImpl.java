package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.*;
import com.cpc.channel.partner.connect.model.DeliveryAddress;
import com.cpc.channel.partner.connect.model.OrderMaster;
import com.cpc.channel.partner.connect.model.OrderSku;
import com.cpc.channel.partner.connect.repository.DeliveryAddressRepository;
import com.cpc.channel.partner.connect.repository.OrderMasterRepository;
import com.cpc.channel.partner.connect.repository.OrderSkuRepository;
import com.cpc.channel.partner.connect.utils.OrderUtils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderServiceImpl implements OrderService {

    private final OrderMasterRepository orderMasterRepository;

    private final OrderSkuRepository orderSkuRepository;
    
    private final DeliveryAddressRepository deliveryAddressRepository;
    
    private final DozerBeanMapper mapper;
    
    private static <T, U> List<U> listMap(Mapper mapper, List<T> source, Class<U> destType) {
        return source.stream().map(element -> mapper.map(element, destType)).collect(Collectors.toList());
    }
    
    @Override
    public OrderMaster getOrder(long orderId) {
        log.info("OrderServiceImpl.getOrder");
        return orderMasterRepository.findById(orderId).orElse(new OrderMaster());
    }


    @Override
    public OrderSku getSkuOrder(long orderId) {
        log.info("OrderServiceImpl.getOrder");
        return orderSkuRepository.findById(orderId).orElse(new OrderSku());
    }


	@Override
	public BaseDto addNtProductsToCart(CartDto cartDto) {
		BaseDto cartResponse = new BaseDto();
		Optional<OrderSku> getCart = orderSkuRepository.findBySapCodeAndProductCodeAndPlacedFalse(cartDto.getSapCode(), cartDto.getProductCode());
		if(getCart.isPresent()) {
			OrderSku orderSku = getCart.get();
			if(orderSku.getQuantity()==cartDto.getQuantity()) {
				cartResponse.setResponseMessage("Selected product is already added to cart.");
				return cartResponse;
			}
			orderSku.setQuantity(cartDto.getQuantity());
			orderSku.setCreatedDate(new Date());
			orderSkuRepository.save(orderSku);
			cartResponse.setResponseMessage("Product quantity updated.");
		}else {
			OrderSku addCart = new OrderSku();
			addCart.setSegmentCode(cartDto.getSegmentCode());
			addCart.setCategory(cartDto.getCategory());
			addCart.setProductCode(cartDto.getProductCode());
			addCart.setProductName(cartDto.getProductName());
			addCart.setQuantity(cartDto.getQuantity());
			addCart.setProductSku(cartDto.getProductSku());
			addCart.setSapCode(cartDto.getSapCode());
			addCart.setCreatedDate(new Date());
			orderSkuRepository.save(addCart);
			cartResponse.setResponseMessage("Products added to cart successfully.");
		}
		return cartResponse;
	}


	@Override
	public CartListDto getCartList(String sapCode, String segmentCode) {
		CartListDto cartListResponse = new CartListDto();
		List<OrderSku> cartDetails = orderSkuRepository.findAllCartProductsBySapcode(sapCode, segmentCode, false);
		if(!cartDetails.isEmpty()) {
			int totalItems = cartDetails.size();
			double totalQuantity = cartDetails.stream().mapToDouble(OrderSku::getQuantity).sum();
			List<CartDto> cartDtoList = listMap(mapper, cartDetails, CartDto.class);
			cartListResponse.setCartList(cartDtoList);
			cartListResponse.setSapCode(sapCode);
			cartListResponse.setTotalAmount(totalQuantity);
			cartListResponse.setTotalCount(totalItems);
		}
		return cartListResponse;
	}

	@Override
	public int getCartCount(String sapCode,String segmentCode) {
		CartListDto cartList = this.getCartList(sapCode, segmentCode);
		return cartList.getTotalCount();
	}

	@Override
	public BaseDto updateCart(CartDto cartDto) {
		BaseDto cartResponse = new BaseDto();
		Optional<OrderSku> getCart = orderSkuRepository.findBySapCodeAndProductCodeAndPlacedFalse(cartDto.getSapCode(), cartDto.getProductCode());
		if(getCart.isPresent()) {
			OrderSku cart = getCart.get();
			cart.setQuantity(cartDto.getQuantity());
			orderSkuRepository.save(cart);
			cartResponse.setResponseMessage("Cart details updated successfully.");
		}else {
			cartResponse.setResponseMessage("Cart details for "+cartDto.getProductName()+" not found");
		}
		return cartResponse;
	}

	@Override
	public BaseDto removeProductFromCart(String sapCode, String productCode) {
		BaseDto cartResponse = new BaseDto();
		Optional<OrderSku> getCart = orderSkuRepository.findBySapCodeAndProductCodeAndPlacedFalse(sapCode, productCode);
		if(getCart.isPresent()) {
			orderSkuRepository.deleteProductFromCart(sapCode, productCode);
			cartResponse.setResponseMessage("Product removed from cart");
		}else {
			cartResponse.setResponseMessage(productCode+" not found in cart. Product cannot be deleted");
        }
		return cartResponse;
	}

	@Override
	public BaseDto deleteAllItemsFromCart(String sapCode, String segmentCode) {
		BaseDto cartResponse = new BaseDto();
		List<OrderSku> getCart = orderSkuRepository.findAllCartProductsBySapcode(sapCode, segmentCode,false);
		if(!getCart.isEmpty()) {
			orderSkuRepository.deleteAllProductFromCart(sapCode);
			cartResponse.setResponseMessage("Product removed from cart");
		}else {
			cartResponse.setResponseMessage("No Products found for user");
        }
		return cartResponse;
	}

	@Override
	public PlaceOrderResponse placeNtOrder(PlaceOrderRequest placeOrder) {
		PlaceOrderResponse orderResponse = new PlaceOrderResponse();
		
		List<OrderSku> orderPlacedList = new ArrayList<>();
		String orderId = OrderUtils.generateOrderId();
		OrderMaster orderMaster = new OrderMaster();
		saveOrderDetails(placeOrder, orderId, orderMaster);
		OrderMaster placedOrder = orderMasterRepository.save(orderMaster);
		for(CartDto cartProducts:placeOrder.getCartList()) {
			OrderSku skus = mapper.map(cartProducts, OrderSku.class);
			skus.setPlaced(true);
			skus.setOrderMaster(placedOrder);
			orderPlacedList.add(skus);
		}
		orderSkuRepository.saveAll(orderPlacedList);
		orderResponse.setOrderId(orderId);
		orderResponse.setResponseMessage("YOUR ORDER NUMBER "+orderId);
		orderResponse.setStatus(HttpStatus.CREATED.value());
		return orderResponse;
	}

	private void saveOrderDetails(PlaceOrderRequest placeOrder, String orderId, OrderMaster orderMaster) {
		DeliveryAddressDto deliveryAddressDto = placeOrder.getDeliveryAddressDto();
		Optional<DeliveryAddress> address = deliveryAddressRepository.findByAddress(placeOrder.getSapCode(), deliveryAddressDto.getAddressLine1(),
				deliveryAddressDto.getAddressLine2(), deliveryAddressDto.getAddressLine3());
		if(address.isEmpty()) {
			DeliveryAddress deliveryDetails = mapper.map(deliveryAddressDto, DeliveryAddress.class);
			deliveryAddressRepository.save(deliveryDetails);
			orderMaster.setAddress(deliveryDetails);
		}else {
			orderMaster.setAddress(address.get());
		}
		orderMaster.setOrderPlacedDate(LocalDateTime.now());
		orderMaster.setDeliveryDate(placeOrder.getDeliveryDate());
		orderMaster.setDeliveryTimeSlot(placeOrder.getTimeSlot());
		orderMaster.setDriverMobileNo(placeOrder.getDriverMobileNo());
		orderMaster.setSapOrderId(orderId);
		orderMaster.setOrderStatus("ACCEPTED");
		orderMaster.setSapCode(placeOrder.getSapCode());
		orderMaster.setVehicleNo(placeOrder.getVehicleNo());
		orderMaster.setShipToCode(placeOrder.getShipToCode());
		orderMaster.setShipToName(placeOrder.getShipToDesc());
		orderMaster.setSegmentCode(placeOrder.getSegmentCode());
		orderMaster.setSpecialInstructions(placeOrder.getSpecialInstructions());
	}

	@Override
	public ListResponse<OrderListResponse> getOrderList(String sapCode, String segmentCode, String status, int pageNo) {
		ListResponse<OrderListResponse> orderListResponse = new ListResponse<>();
		List<OrderMaster> orderList = new ArrayList<>();
		int offset = 0;
        if (pageNo != 0) {
            offset = (pageNo * 50);
        }
		if("ONGOING".equalsIgnoreCase(status)) {
			var orderStatus = List.of("ACCEPTED","PENDING","ACKNOWLEDGED","REJECTED");
		    orderList = orderMasterRepository.findBySapCodeAndSegmentCodeAndOrderStatusIn(sapCode, segmentCode, orderStatus);
		}
		if("DISPATCHED".equalsIgnoreCase(status)) {
			var orderStatus = List.of("COMPLETED","CONFIRMED");
			orderList = orderMasterRepository.findBySapCodeAndSegmentCodeAndOrderStatusIn(sapCode, segmentCode, orderStatus);
		}
		orderListResponse.setTotalCount(orderList.size());
		orderListResponse.setList(listMap(mapper, orderList, OrderListResponse.class).stream().skip(offset).limit(50).collect(Collectors.toList()));
		return orderListResponse;
	}

	@Override
	public List<ViewSalesReportDto> getSalesReportDetails(UserRequestDetailsDto salesReportRequest) {
		List<ViewSalesReportDto> salesReportData = new ArrayList<>();
		var firstDay = salesReportRequest.getInputDate().with(TemporalAdjusters.firstDayOfMonth());
		var lastDayofMonth = salesReportRequest.getInputDate().with(TemporalAdjusters.lastDayOfMonth());
		List<OrderProjectionDto> findAllBySapCode = orderMasterRepository.findAllOrderDetails(salesReportRequest.getSapCode(), 
				salesReportRequest.getSegmentCode(), firstDay, lastDayofMonth);
		var salesData = listMap(mapper, findAllBySapCode, OrderMaster.class);
		var getOrderInvoiceDetails = getOrderWiseInvoiceDetails(salesData);
		List<String> orderIds = salesData.stream().map(OrderMaster::getSapOrderId).distinct().collect(Collectors.toList());
		for(String orderId:orderIds) {
			ViewSalesReportDto reportDto = new ViewSalesReportDto();
			OrderMaster orderData = salesData.stream().filter(p -> orderId.equals(p.getSapOrderId())).findFirst().orElse(new OrderMaster());
			var orderInvoice = getOrderInvoiceDetails.get(orderId);
			reportDto.setSapOrderId(orderId);
			reportDto.setOrderDate(orderData.getOrderPlacedDate());
			reportDto.setInvoiceCount(orderInvoice.size());
			reportDto.setInvoiceDetails(orderInvoice);
			reportDto.setTotalQuantity(orderInvoice.stream().mapToDouble(InvoiceDetails::getInvoiceQuantity).sum());
			salesReportData.add(reportDto);
		}
		return salesReportData;
	}

	@Override
	public List<ProductWiseSalesDto> getSumOfProductsAsPerMonth(String sapCode, LocalDateTime currentDate) {
		LocalDateTime fromDate = currentDate.with(TemporalAdjusters.firstDayOfMonth());
		LocalDateTime toDate = currentDate.with(TemporalAdjusters.lastDayOfMonth());
		return orderMasterRepository.findProductsBySapCodeAndProductCodeAndBetweenOrderDate(sapCode, fromDate, toDate);
	}

	private HashMap<String, List<InvoiceDetails>> getOrderWiseInvoiceDetails(List<OrderMaster> orderDetails){
		HashMap<String, List<InvoiceDetails>> invoiceDetailsResponse = new HashMap<>();
		for(OrderMaster order : orderDetails) {
			if(invoiceDetailsResponse.containsKey(order.getSapOrderId())) {
				invoiceDetailsResponse.get(order.getSapOrderId()).add(new InvoiceDetails(order.getInvoiceNo(), order.getQuantity()));
			}else {
				List<InvoiceDetails> invoices = new ArrayList<>();
				invoices.add(new InvoiceDetails(order.getInvoiceNo(), order.getQuantity()));
                invoiceDetailsResponse.put(order.getSapOrderId(), invoices);
			}
		}
		return invoiceDetailsResponse;
	}
	
	
}
