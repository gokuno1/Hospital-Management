package com.cpc.channel.partner.connect.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class OrderUtils {

	private OrderUtils() {
	}

	public static final String TIME_STAMP_FORMAT = "ddHHmmSSS";
	
	public static String generateOrderId() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(TIME_STAMP_FORMAT); 
		return "OID" + dateFormat.format(new Date());
	}
}
