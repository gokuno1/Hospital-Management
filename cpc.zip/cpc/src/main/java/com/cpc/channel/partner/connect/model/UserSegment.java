package com.cpc.channel.partner.connect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "user_segment_mapping", catalog = "cpc_service")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserSegment {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_SEGMENT_ID")
	private int userSegmentId;
	
	@Column(name = "SAP_CODE")
	private String userSapCode;
	
	@Column(name = "SEGMENT_CODE")
	private String segmentCode;
	
	@Column(name = "SEGMENT_NAME")
	private String segmentName;
	
	@Column(name = "IS_ACTIVE")
	private boolean active;

}
