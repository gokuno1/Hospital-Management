package com.cpc.channel.partner.connect.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "order_master")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SalesReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ORDER_ID")
    private long orderId;

    @Column(name = "SAP_ORDER_ID")
    private String sapOrderId;

    @Column(name = "SAP_CODE")
    private String sapCode;

    @Column(name = "ORDER_STATUS")
    private String status;

    @Column(name = "ORDER_PLACED_DATE")
    private LocalDateTime orderPlacedDate;

    @Column(name = "ORDER_QUANTITY")
    private double orderQuantity;

}
