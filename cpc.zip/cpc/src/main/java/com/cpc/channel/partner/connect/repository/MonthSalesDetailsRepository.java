package com.cpc.channel.partner.connect.repository;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cpc.channel.partner.connect.model.MonthSalesDetails;

@Repository
public interface MonthSalesDetailsRepository extends JpaRepository<MonthSalesDetails, Integer>{

	@Query(value = "SELECT MONTH_SALES_ID, SAP_CODE, PREV_MONTH_SALES, CURRENT_MONTH_SALES, PREV_YEAR_SALES, \r\n" + 
			"CONCAT(MONTHNAME(MONTH_DATE),' ',DATE_FORMAT(MONTH_DATE,'%Y')) as MONTH_DATE\r\n" + 
			"FROM cpc_service.month_sales where SAP_CODE=?1 AND MONTH_DATE=?2", nativeQuery = true)
	Optional<MonthSalesDetails> getMonthSalesDetails(String sapCode, LocalDateTime currentDate);
	
}
