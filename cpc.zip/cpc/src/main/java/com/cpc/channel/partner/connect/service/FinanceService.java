package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.CashDiscountDto;
import com.cpc.channel.partner.connect.dto.FinanceDto;
import com.cpc.channel.partner.connect.dto.FinancePaymentDto;

import java.time.LocalDateTime;
import java.util.List;

public interface FinanceService {

//    List<FinanceDto> getFinanceList(String sapCode);

    FinanceDto getFinanceStats(String sapCode);

    List<FinancePaymentDto> getFinancePaymentList(String sapCode);

    CashDiscountDto getCashDiscount(String sapCode, LocalDateTime date);

}
