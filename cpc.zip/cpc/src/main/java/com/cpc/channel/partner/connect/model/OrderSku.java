package com.cpc.channel.partner.connect.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "order_sku_details")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderSku {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ORDER_SKU_DETAILS_ID")
    private long orderSkuId;

    @Column(name = "SAP_CODE")
    private String sapCode;

    @Column(name = "SEGMENT_CODE")
    private String segmentCode;

    @Column(name = "PRODUCT_CODE")
    private String productCode;

    @Column(name = "PRODUCT_NAME")
    private String productName;

    @Column(name = "CATEGORY_NAME")
    private String category;

    @Column(name = "ORDER_QUANTITY")
    private int quantity;

    @Column(name = "IS_PLACED")
    private boolean placed;

    @Column(name = "PRODUCT_SKU")
    private String productSku;
    
    @Column(name = "CREATED_DATE")
    private Date createdDate;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="ORDER_ID")
    private OrderMaster orderMaster;


}
