package com.cpc.channel.partner.connect.utils;

import org.dozer.Mapper;

import java.util.List;
import java.util.stream.Collectors;

public class ListObjectMapper {

    private ListObjectMapper() {

    }

    public static <T, U> List<U> listMap(Mapper mapper, List<T> source, Class<U> destType) {
        return source.stream().map(e -> mapper.map(e, destType)).collect(Collectors.toList());

    }

}
