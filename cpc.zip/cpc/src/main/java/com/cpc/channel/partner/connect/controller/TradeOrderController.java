package com.cpc.channel.partner.connect.controller;

import com.cpc.channel.partner.connect.dto.*;
import com.cpc.channel.partner.connect.service.TradeService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("trade/orders")
@RequiredArgsConstructor
public class TradeOrderController {

    private final TradeService tradeService;

    @PostMapping
    @Operation(description = "Place Trade Order API")
    public ResponseEntity<BaseDto> placeOrder(@RequestBody TradeOrderDto tradeOrderDto) {
        PlaceOrderResponse response = tradeService.placeOrder(tradeOrderDto);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(description = "Trade ongoing and dispatched orders")
    public ResponseEntity<ListResponse<TradeOrderResponse>> getOrders(@RequestHeader String segmentCode,
                                                                      @RequestHeader String sapCode, @RequestHeader String orderStatus,
                                                                      @RequestHeader String filterBy, @RequestHeader int pageNo) {
        ListResponse<TradeOrderResponse> orders = tradeService.getOrders(segmentCode, sapCode, orderStatus, filterBy, pageNo);
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/{sapOrderId}")
    @Operation(description = "Trade ongoing and dispatched orders")
    public ResponseEntity<TradeOrderDto> getOrder(@PathVariable String sapOrderId,
                                                  @RequestHeader String sapCode) {
        TradeOrderDto order = tradeService.getOrder(sapOrderId, sapCode);
        return ResponseEntity.ok(order);
    }


}
