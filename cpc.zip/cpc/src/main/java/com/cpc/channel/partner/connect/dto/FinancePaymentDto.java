package com.cpc.channel.partner.connect.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FinancePaymentDto {


    private String sapCode;

    private String transactionId;

    private LocalDateTime paymentDate;

    private double amount;
}

