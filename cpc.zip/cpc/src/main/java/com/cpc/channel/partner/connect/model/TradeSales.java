package com.cpc.channel.partner.connect.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "trade_sales")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TradeSales {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private long tradeSalesId;

    @Column(name = "SAP_CODE")
    private String sapCode;

    @Column(name="TARGET_QUANTITY")
    private double targetQuantity;

    @Column(name = "ONGOING_QUANTITY")
    private double onGoingQuantity;

    @Column(name = "BALANCE_QUANTITY")
    private double balanceQuantity;

    @Column(name = "ACHIEVED_QUANTITY")
    private double achievedQuantity;

    @Column(name = "ORDER_PLACED_DATE")
    private LocalDateTime orderPlacedDate;

    @Column(name = "DISPATCHED_DATE")
    private LocalDateTime dispatchedDate;

    @Column(name = "DELIVERY_DATE")
    private LocalDateTime deliveryDate;

    @Column(name = "ORDER_STATUS")
    private String orderStatus;
}
