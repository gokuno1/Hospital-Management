package com.cpc.channel.partner.connect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "nt_product_master", catalog = "cpc_service")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NtProductMaster {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "NONTRADE_PRODUCT_ID")
	private int productMasterId;
	
	@Column(name = "PRODUCT_CODE")
	private String ntProductCode;
	
	@Column(name = "PRODUCT_NAME")
	private String ntProductName;
	
	@Column(name = "CATEGORY_NAME")
	private String categoryName;
	
	@Column(name = "IS_ACTIVE")
	private boolean isActive;
	
	@Column(name = "PRODUCT_SKU")
	private String productSku;
	
}
