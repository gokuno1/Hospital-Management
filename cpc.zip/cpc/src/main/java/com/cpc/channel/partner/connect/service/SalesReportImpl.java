package com.cpc.channel.partner.connect.service;

import com.cpc.channel.partner.connect.dto.SalesReportDto;
import com.cpc.channel.partner.connect.repository.SalesReportRepository;
import lombok.RequiredArgsConstructor;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SalesReportImpl implements SalesReportService{

    private final SalesReportRepository salesReportRepository;
    private final DozerBeanMapper mapper;

    private static <T, U> List<U> listMap(Mapper mapper, List<T> source, Class<U> destType) {
        List<U> dest = new ArrayList<>();
        source.stream().forEach(element -> dest.add(mapper.map(element, destType)));
        return dest;
    }


    @Override
    public List<SalesReportDto> getSalesReport(String sapCode, LocalDateTime currentDate){
    	LocalDateTime fromDate = currentDate.with(TemporalAdjusters.firstDayOfMonth());
    	LocalDateTime toDate = currentDate.with(TemporalAdjusters.lastDayOfMonth());
        return listMap(mapper,salesReportRepository.findBySapCode(sapCode, fromDate, toDate),SalesReportDto.class);
    }

}
