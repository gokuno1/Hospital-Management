package com.cpc.channel.partner.connect.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlaceOrderRequest {
	
	private String shipToCode;
	private String shipToDesc;
	private LocalDateTime deliveryDate;
	private String timeSlot;
	private String vehicleNo;
	private String driverMobileNo;
	private String driverName;
	private String customerName;
	private String sapCode;
	private DeliveryAddressDto deliveryAddressDto;
	private List<CartDto> cartList;
	private String specialInstructions;
	private String segmentCode;
	

}
