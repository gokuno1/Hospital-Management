package com.cpc.channel.partner.connect.controller;

import java.util.List;

import javax.validation.Valid;

import static org.springframework.http.HttpStatus.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cpc.channel.partner.connect.dto.AddressPincodeDetailsDto;
import com.cpc.channel.partner.connect.dto.CategoryDto;
import com.cpc.channel.partner.connect.dto.DeliveryDetailsDto;
import com.cpc.channel.partner.connect.dto.ProductMasterDto;
import com.cpc.channel.partner.connect.dto.ProductRequest;
import com.cpc.channel.partner.connect.dto.UserSegmentDto;
import com.cpc.channel.partner.connect.service.MasterService;
import com.cpc.channel.partner.connect.utils.CpcConstants;
import com.cpc.channel.partner.connect.utils.ListResponseVO;
import com.cpc.channel.partner.connect.utils.ResponseUtils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/master")
@RequiredArgsConstructor
@Slf4j
public class MasterController {
	
	private final MasterService masterService;

	@PostMapping("/nt-products")
    public ResponseEntity<ProductMasterDto> getNtProducts(@Valid @RequestBody ProductRequest productRequest) {
		log.info("Inside Controller method products");
		ProductMasterDto products = masterService.getNtProducts(productRequest);
		log.info("After Controller method products");
		return ResponseEntity.ok(products);
    }
	
	@PostMapping("/products")
    public ResponseEntity<ProductMasterDto> getProducts(@Valid @RequestBody ProductRequest productRequest) {
		log.info("Inside Controller method products");
		ProductMasterDto products = masterService.getProducts(productRequest);
		log.info("After Controller method products");
		return ResponseEntity.ok(products);
    }
	
	@GetMapping("/segments")
	public ResponseEntity<ListResponseVO<UserSegmentDto>> getUserSegments(@RequestHeader(name = "sapcode") String sapCode){
		List<UserSegmentDto> segments = masterService.getUserSegments(sapCode);
		ListResponseVO<UserSegmentDto> segmentList = new ListResponseVO<>();
		if(!segments.isEmpty()) {
			segmentList.setList(segments);
			segmentList.setStatus(OK.value());
			segmentList.setResponseMessage("Segment details");
			return ResponseUtils.getOKResponse(segmentList);
		}else {
			segmentList.setStatus(NOT_FOUND.value());
			segmentList.setResponseMessage(CpcConstants.NO_DATA_FOUND);
			return ResponseUtils.getNotFoundResponse(segmentList);
		}
	}
	
	@GetMapping("/delivery-details")
	public ResponseEntity<DeliveryDetailsDto> getDeliveryDetails(@RequestHeader(name = "sapcode") String sapCode, 
																 @RequestHeader String locationCode){
		DeliveryDetailsDto deliveryDetails = masterService.getDeliveryDetails(sapCode, locationCode);
		return ResponseEntity.ok(deliveryDetails);
	}
	
	@GetMapping("/category")
	public ResponseEntity<ListResponseVO<CategoryDto>> getNtProductCategory(){
		List<CategoryDto> category = masterService.getNtProductsCategory();
		ListResponseVO<CategoryDto> categoryList = new ListResponseVO<>();
		if(!category.isEmpty()) {
			categoryList.setList(category);
			categoryList.setStatus(OK.value());
			categoryList.setResponseMessage("Category details");
			return ResponseEntity.ok(categoryList);
		}else {
			categoryList.setStatus(NOT_FOUND.value());
			categoryList.setResponseMessage(CpcConstants.NO_DATA_FOUND);
			return ResponseUtils.getNotFoundResponse(categoryList);
		}
	}
	
	@GetMapping("/delivery-address")
	public ResponseEntity<AddressPincodeDetailsDto> getDeliveryAddress(@RequestHeader(name = "sapcode") String sapCode, 
																 @RequestHeader String shipToCode){
		AddressPincodeDetailsDto deliveryAddress = masterService.getDeliveryAddress(sapCode, shipToCode);
		return ResponseUtils.getOKResponse(deliveryAddress);
	}
}
