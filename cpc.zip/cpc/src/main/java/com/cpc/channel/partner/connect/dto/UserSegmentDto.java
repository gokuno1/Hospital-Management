package com.cpc.channel.partner.connect.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserSegmentDto {

	private int userSegmentId;
	
	private String userSapCode;
	
	private String segmentCode;
	
	private String segmentName;
	
	private boolean active;
	
}
