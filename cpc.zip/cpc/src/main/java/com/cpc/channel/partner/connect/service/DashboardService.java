package com.cpc.channel.partner.connect.service;

import java.time.LocalDateTime;

import com.cpc.channel.partner.connect.dto.OrderOverview;

public interface 	DashboardService {

	OrderOverview getDashboardOrderOverview(String sapCode, String segmentCode, LocalDateTime currentDate);
	
}
